# Selector-v3.2.1 paired canary

**Canary gate: HOLD**

- Requirements: `{"disabled_overlay_point_worst_at_least_0_98": true, "numerical_exact": true, "paired_policy_point_worst_at_least_0_98": false, "policy_point_worst_at_least_0_98": false, "selected_nonempty": true, "selected_point_worst_at_least_0_98": true}`
