"""CPU ownership boundaries for an explicitly SHA-bound research draft."""

import hashlib
import json
import os
import subprocess
import tarfile
import time
from pathlib import Path

b = Path('/ssd/scxi253')
p = b / 'sgi-reusable-lease-cpu-20261001T1543Z'
p.mkdir()
a = b / 'reusable-lease-draft-20261001T1543Z.tar.gz'
r = json.loads((b / 'reusable-lease-draft-20261001T1543Z.json').read_text())
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
assert sha(a) == r['archive_sha256']
with tarfile.open(a) as t:
    assert set(t.getnames()) == set(r['files'])
    for name, expected in r['files'].items():
        assert hashlib.sha256(t.extractfile(name).read()).hexdigest() == expected
    t.extractall(p, filter='data')
for name, expected in r['files'].items():
    assert sha(p / name) == expected
s = b / 'sgi-official-wheel-validation-75544a17-20261001/wheel-overlay'
e = b / 'q7b-engines-20260925T1247Z/envs/sglang312/bin/python'
env = dict(os.environ, CUDA_VISIBLE_DEVICES='', PYTHONPATH=f'{p}:{s}:{s}/test-support',
           PYTEST_DISABLE_PLUGIN_AUTOLOAD='1', PYTHONNOUSERSITE='1', OMP_NUM_THREADS='1')
start = time.monotonic()
with (p / 'tests.log').open('w') as log:
    code = subprocess.run([str(e), '-m', 'pytest', '-q',
        'research/selector_v4/serving/test_reusable_plan_lease.py',
        'research/selector_v4/serving/test_reusable_plan_lease_gpu.py',
        '--confcutdir=research/selector_v4/serving', '--junitxml='+str(p / 'tests.xml')],
        cwd=p, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=1800).returncode
r.update(returncode=code, elapsed_seconds=time.monotonic()-start, gpu_execution=False,
         helper_sha256=sha(Path(__file__)), log_sha256=sha(p / 'tests.log'))
if (p / 'tests.xml').exists(): r['xml_sha256'] = sha(p / 'tests.xml')
(p / 'receipt.json').write_text(json.dumps(r, indent=2)+'\n')
print(json.dumps(r))
raise SystemExit(code)
