"""Build metadata for flashinfer package."""
__version__ = "0.7.1"
__git_commit__ = "eb4e3e60a6de71f00c0fb558da6f21e4b45d8b55"
