"""Normal upstream wheel build for the compiler-header-bound resource revision."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile,zipfile
b=Path('/ssd/scxi253');p=b/'sgi-flashinfer-official-build-eb4e3e60-20261001';p.mkdir();s=p/'source';baseline=b/'sgi-d7683dd-official-sparse-source';base_receipt=b/'sgi-d7683dd-official-sparse-source-receipt.json';r=json.loads(base_receipt.read_text());assert r['main_git_blob_proof']['required_paths_complete'];assert all(x['required_paths_complete'] for x in r['vendor_git_blob_proof'].values())
shutil.copytree(baseline,s,symlinks=True,ignore=shutil.ignore_patterns('__pycache__'))
commit='eb4e3e60a6de71f00c0fb558da6f21e4b45d8b55'
subprocess.run(['git','fetch',str(b/'sgi-eb4e3e60-update.bundle'),'codex/flashinfer-native-resource-v42'],cwd=s,check=True)
subprocess.run(['git','checkout','--detach',commit],cwd=s,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()==commit
proof={}
for row in subprocess.check_output(['git','ls-files','--stage','-z'],cwd=s).split(b'\0'):
 if not row:continue
 meta,path=row.split(b'\t',1);mode,blob,stage=meta.split();f=s/os.fsdecode(path)
 if mode==b'160000':continue
 if not f.exists() and not f.is_symlink():continue
 data=os.readlink(f).encode() if mode==b'120000' else f.read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest().encode()==blob,str(f);proof[os.fsdecode(path)]=blob.decode()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
(p/'input-git-blobs.json').write_text(json.dumps(proof,indent=2)+'\n')
ledger={str(f.relative_to(s)):sha(f) for f in sorted(s.rglob('*')) if f.is_file() and '.git' not in f.relative_to(s).parts};(p/'input-source-files.json').write_text(json.dumps(ledger,indent=2)+'\n')
a=p/'input-source.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for f in sorted(s.iterdir()):t.add(f,arcname=f.name)
(p/'wheels').mkdir();e=b/'q7b-engines-20260925T1247Z/envs/sglang312/bin/python';env=os.environ.copy();env.update(BUILD_NVEP='0',FLASHINFER_BUILD_NO_PIP='1',PYTHONNOUSERSITE='1');env.pop('PYTHONPATH',None)
with (p/'build.log').open('w') as log:subprocess.run([str(e),'-c','import build_backend; print(build_backend.build_wheel("'+str(p/'wheels')+'"))'],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
wheels=list((p/'wheels').glob('*.whl'));assert len(wheels)==1;w=wheels[0]
with zipfile.ZipFile(w) as z:
 meta=z.read('flashinfer/_build_meta.py').decode();assert '__version__ = "0.7.1"' in meta and commit in meta
 for n in z.namelist():
  if n.startswith('flashinfer/') and not n.endswith('/'):
   f=s/n;assert f.is_file(),n;assert hashlib.sha256(z.read(n)).hexdigest()==sha(f),n
 assert hashlib.sha256(z.read('flashinfer/prefill.py')[:344213]).hexdigest()=='059a9dc01d652de9b7b70bbf6efecd736f6086e36f11941cd7eb972b5bbea006'
 distribution=z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))).decode();assert 'Version: 0.7.1\n' in distribution
receipt={'build_pass':True,'source_git_commit':commit,'native_base':'85744da1a397c0c4bea1a83b8345281750eb61a9','baseline_sparse_source_receipt_sha256':sha(base_receipt),'source_archive_sha256':sha(a),'source_archive':str(a),'source_archive_bytes':a.stat().st_size,'vendor_git_pins':{n:x['git_commit'] for n,x in r['vendor_git_blob_proof'].items()},'vendor_git_blob_proof':r['vendor_git_blob_proof'],'input_source_ledger_sha256':sha(p/'input-source-files.json'),'input_git_blobs_sha256':sha(p/'input-git-blobs.json'),'tracked_present_blobs_verified':len(proof),'incremental_bundle_sha256':sha(b/'sgi-eb4e3e60-update.bundle'),'wheel':str(w),'wheel_sha256':sha(w),'wheel_bytes':w.stat().st_size,'metadata':meta,'all_wheel_package_bytes_match_normal_build_source':True,'build_log_sha256':sha(p/'build.log'),'normal_upstream_hook':True,'optional_nvep_build_disabled':True,'hook_package_installs_disabled':True,'shared_python_environment_changed':False,'version_manually_overridden':False,'all_runtime_vendor_header_paths_present':True,'sparse_non_build_paths_omitted':True,'fresh_cases_consumed':0,'gpu_requalification_pending':True,'tests_expected':53,'full_serving_qualified':False}
(p/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
