"""Frozen current-main Qwen HTTP ownership matrix; diagnostic timing only."""
from pathlib import Path
import argparse, asyncio, hashlib, json, os, random, signal, socket, subprocess, sys, time
import aiohttp

def save(path,data):path.write_text(json.dumps(data,indent=2)+'\n')
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()

async def collect(session,url,payload,expected,count=1,disconnect=False):
    started=time.monotonic();events=[];final={};done=False;error=None;status=None
    try:
        async with session.post(url+'/generate',json=payload) as response:
            status=response.status
            if status!=200:error='HTTP '+str(status)+': '+(await response.text())[:4000]
            else:
                fields=[]
                async for line in response.content:
                    text=line.decode('utf8').rstrip('\r\n')
                    if text.startswith('data:'):fields.append(text[5:].lstrip())
                    elif not text and fields:
                        data='\n'.join(fields);fields=[];events.append(data)
                        if len(events)>4096:raise RuntimeError('bounded SSE event limit')
                        if data=='[DONE]':done=True;continue
                        obj=json.loads(data)
                        if 'error' in obj:raise RuntimeError(str(obj['error']))
                        rows=obj if isinstance(obj,list) else [obj]
                        for row in rows:
                            key=int(row.get('index',0));final[key]=row
                        if disconnect:break
                if fields:raise RuntimeError('unterminated SSE event')
    except Exception as exc:error=type(exc).__name__+': '+str(exc)
    complete=not disconnect and error is None and done and len(final)==count and all(row.get('meta_info',{}).get('completion_tokens')==expected and row.get('meta_info',{}).get('finish_reason',{}).get('type')=='length' for row in final.values())
    return {'complete':complete,'intentional_disconnect':disconnect,'status':status,'error':error,'expected_tokens_per_sample':expected,'expected_samples':count,'final_rows':final,'done':done,'frames':events,'elapsed_seconds':time.monotonic()-started,'diagnostic_only':True}

async def run(root,out,mode):
    if out.exists():raise FileExistsError('retain earlier evidence')
    out.mkdir(parents=True);src=root/mode/'python'
    env=dict(os.environ,PYTHONPATH=str(src)+':'+os.environ['SGI_PRISTINE_OVERLAY'],SGI_HTTP_OWNER_LOG=str(out/'cleanup.jsonl'),HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1')
    module=src/'sglang/srt/managers/tokenizer_manager.py'
    expected=json.loads((root/'source-binding.json').read_text())[mode]
    if sha(module)!=expected:raise RuntimeError('exact upstream source drift')
    with socket.socket() as sock:sock.bind(('127.0.0.1',0));port=sock.getsockname()[1]
    model=Path('/ssd/scxi253/check-before-act-20260927/models/Qwen3-4B-Instruct-2507')
    command=[sys.executable,str(root/'http_ownership_server.py'),'--model-path',str(model),'--host','127.0.0.1','--port',str(port),'--attention-backend','flashinfer','--dtype','bfloat16','--mem-fraction-static','0.80','--context-length','8192','--chunked-prefill-size','1024','--max-running-requests','16','--cuda-graph-max-bs-decode','16','--page-size','16','--skip-tokenizer-init','--disable-radix-cache','--random-seed','42','--disable-overlap-schedule']
    save(out/'environment.json',{'mode':mode,'command':command,'tokenizer_manager_sha256':expected,'model_config_sha256':sha(model/'config.json'),'model_index_sha256':sha(model/'model.safetensors.index.json'),'probe_sha256':sha(Path(__file__)),'server_observer_sha256':sha(root/'http_ownership_server.py'),'diagnostic_only':True,'resource_cap_enabled':False,'single_worker':True,'upstream_accepted':False})
    log=(out/'server.log').open('w');proc=subprocess.Popen(command,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
    url=f'http://127.0.0.1:{port}';results=[]
    try:
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=180)) as session:
            tick=time.monotonic()
            while time.monotonic()-tick<720:
                if proc.poll() is not None:raise RuntimeError('server exited '+str(proc.returncode))
                try:
                    async with session.get(url+'/health',timeout=aiohttp.ClientTimeout(total=3)) as response:
                        if response.status==200:break
                except (aiohttp.ClientError,asyncio.TimeoutError):pass
                await asyncio.sleep(.5)
            else:raise TimeoutError('startup timeout')
            rng=random.Random(936655);ids=[rng.randrange(200,16000) for _ in range(128)]
            async def request(name,rid,n,inputs=ids,samples=1,disconnect=False):
                payload={'rid':rid,'input_ids':inputs,'sampling_params':{'temperature':0,'max_new_tokens':n,'ignore_eos':True,'n':samples},'stream':True}
                rec=await collect(session,url,payload,n,count=samples if not isinstance(inputs[0],list) else len(inputs)*samples,disconnect=disconnect)
                rec['name']=name;rec['rid']=rid;save(out/(name+'.json'),rec);results.append(rec)
            await request('warmup','warmup',16);await asyncio.sleep(2.2)
            for epoch in range(2):
                await request(f'reused-{epoch}-first',f'reuse-{epoch}',16)
                await request(f'reused-{epoch}-replacement',f'reuse-{epoch}',512)
                await asyncio.sleep(2.2)
            await request('unique-0','unique-0',512);await request('unique-1','unique-1',512)
            await request('batch-two',['batch-0','batch-1'],128,inputs=[ids,ids])
            await request('parallel-two',None,128,samples=2);await asyncio.sleep(2.5)
            await request('disconnect-parallel',None,512,samples=2,disconnect=True);await asyncio.sleep(3)
            await request('after-disconnect','after-disconnect',128);await asyncio.sleep(2.5)
        events=[json.loads(line) for line in (out/'cleanup.jsonl').read_text().splitlines()]
        bad_remaining=[event for event in events if event['event']=='cleanup-end' and event.get('remaining_owned')]
        stale_aborts=[event for event in events if event['event']=='abort' and event.get('owner') is not None and event.get('owner')!=event.get('target_object') and isinstance(event.get('rid'),str) and event['rid'].startswith('reuse-')]
        checked=[r for r in results if not r['intentional_disconnect']]
        summary={'complete':True,'mode':mode,'request_count':len(results),'checked_requests':len(checked),'all_checked_complete':all(r['complete'] for r in checked),'incomplete_names':[r['name'] for r in checked if not r['complete']],'intentional_disconnects':sum(r['intentional_disconnect'] for r in results),'remaining_owned_at_cleanup':bad_remaining,'stale_reused_rid_aborts':stale_aborts,'candidate_pass':mode=='candidate' and all(r['complete'] for r in checked) and not bad_remaining and not stale_aborts,'diagnostic_only':True,'performance_promotion':False,'token_divergence_fixed':False}
        save(out/'complete.json',summary);print(json.dumps(summary,indent=2),flush=True)
    except BaseException as exc:save(out/'failure.json',{'type':type(exc).__name__,'message':str(exc)});raise
    finally:
        if proc.poll() is None:
            os.killpg(proc.pid,signal.SIGTERM)
            try:proc.wait(timeout=20)
            except subprocess.TimeoutExpired:os.killpg(proc.pid,signal.SIGKILL);proc.wait(timeout=10)
        log.close()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--root',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--mode',choices=['original','candidate'],required=True);a=p.parse_args();asyncio.run(run(a.root,a.out,a.mode))
