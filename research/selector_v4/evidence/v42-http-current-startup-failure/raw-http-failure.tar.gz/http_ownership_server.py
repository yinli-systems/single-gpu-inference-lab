"""Observe exact current-main cleanup without replacing its production methods."""
from pathlib import Path
import contextvars, hashlib, inspect, json, os, runpy, time
from sglang.srt.managers.tokenizer_manager import TokenizerManager

log=Path(os.environ['SGI_HTTP_OWNER_LOG']);context=contextvars.ContextVar('cleanup_owner',default=None)
def emit(data):
    with log.open('a') as f:f.write(json.dumps({'time':time.monotonic(),'pid':os.getpid(),**data})+'\n')
original_init=TokenizerManager._init_req_state
original_abort=TokenizerManager.abort_request
original_create=TokenizerManager.create_abort_task

def initialize(self,obj,*args,**kwargs):
    result=original_init(self,obj,*args,**kwargs)
    emit({'event':'register','rid':obj.rid,'owner':id(kwargs.get('abort_owner',obj)),'state_count':len(self.rid_to_state)})
    return result

def abort(self,rid='',abort_all=False):
    state=self.rid_to_state.get(rid)
    emit({'event':'abort','rid':rid,'owner':context.get(),'target_object':None if state is None else id(state.obj),'target_state':None if state is None else id(state),'dispatched':None if state is None else state.dispatched})
    return original_abort(self,rid=rid,abort_all=abort_all)

def create(self,obj):
    tasks=original_create(self,obj)
    for task in tasks.tasks:
        fn=task.func
        async def invoke(fn=fn,obj=obj):
            token=context.set(id(obj));emit({'event':'cleanup-start','rid':obj.rid,'owner':id(obj),'state_count':len(self.rid_to_state)})
            try:return await fn()
            finally:
                markers=obj.__dict__.get('_http_abort_states',{})
                remaining=[rid for rid,gen in markers.items() if (state:=self.rid_to_state.get(rid)) is not None and state.abort_generation is gen]
                emit({'event':'cleanup-end','rid':obj.rid,'owner':id(obj),'state_count':len(self.rid_to_state),'remaining_owned':remaining})
                context.reset(token)
        task.func=invoke
    return tasks

TokenizerManager._init_req_state=initialize;TokenizerManager.abort_request=abort;TokenizerManager.create_abort_task=create
emit({'event':'installed','method_sha256':hashlib.sha256(inspect.getsource(original_create).encode()).hexdigest(),'module_path':inspect.getfile(TokenizerManager)})
if __name__=='__main__':runpy.run_module('sglang.launch_server',run_name='__main__')
