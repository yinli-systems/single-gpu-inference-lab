# Selector v4 safe-autotune qualification

**gpu_5090: PASS**

- Cross-fit records: 144; selected 108 (75.0%).
- Held-out selected geomean 1.398568x; point worst 1.305171x; block worst 1.300678x; joint-min LCB 1.304803x.
- Whole-policy geomean 1.286064x; worst 1.000000x.
- Candidate-native / pristine geomean 0.999523x; worst 0.995325x; joint-min LCB 0.992892x.
- Requirements: `{"actual_policy_vs_pristine_worst_at_least_0_99": true, "all_execution_modes_selected": true, "both_dtypes_selected": true, "both_layouts_selected": true, "cache_roundtrip": true, "compiled_kernel_symbol_isolation": true, "held_out_controls_resolve": true, "native_after_cap_exact": true, "native_overlay_controls_resolve_one_percent": true, "native_overlay_joint_min_lcb_at_least_0_99": true, "native_overlay_worst_at_least_0_99": true, "native_sass_identity": true, "native_source_identity": true, "numerical_exact": true, "policy_worst_at_least_0_99": true, "selected_block_worst_at_least_0_99": true, "selected_geomean_at_least_1_05": true, "selected_joint_min_lcb_at_least_0_99": true, "selected_nonempty": true, "selected_worst_at_least_0_99": true, "telemetry_stable": true}`
