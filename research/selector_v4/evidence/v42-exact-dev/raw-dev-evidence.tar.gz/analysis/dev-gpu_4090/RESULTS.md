# Selector v4 safe-autotune qualification

**gpu_4090: PASS**

- Cross-fit records: 144; selected 144 (100.0%).
- Held-out selected geomean 1.385991x; point worst 1.317030x; block worst 1.311594x; joint-min LCB 1.316414x.
- Whole-policy geomean 1.385991x; worst 1.317030x.
- Candidate-native / pristine geomean 0.998435x; worst 0.995516x; joint-min LCB 0.993662x.
- Requirements: `{"actual_policy_vs_pristine_worst_at_least_0_99": true, "all_execution_modes_selected": true, "both_dtypes_selected": true, "both_layouts_selected": true, "cache_roundtrip": true, "compiled_kernel_symbol_isolation": true, "held_out_controls_resolve": true, "native_after_cap_exact": true, "native_overlay_controls_resolve_one_percent": true, "native_overlay_joint_min_lcb_at_least_0_99": true, "native_overlay_worst_at_least_0_99": true, "native_sass_identity": true, "native_source_identity": true, "numerical_exact": true, "policy_worst_at_least_0_99": true, "selected_block_worst_at_least_0_99": true, "selected_geomean_at_least_1_05": true, "selected_joint_min_lcb_at_least_0_99": true, "selected_nonempty": true, "selected_worst_at_least_0_99": true, "telemetry_stable": true}`
