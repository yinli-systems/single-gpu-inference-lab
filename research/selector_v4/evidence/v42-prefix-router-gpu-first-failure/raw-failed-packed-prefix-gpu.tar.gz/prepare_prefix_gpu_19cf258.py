"""Source-bound exposed functional registry checks, no qualification authority."""
import hashlib,json,shutil,subprocess,tarfile
from pathlib import Path
b=Path('/ssd/scxi253');p=b/'sgi-prefix-router-gpu-19cf258-75544a17-20261001'
v=b/'sgi-official-wheel-validation-75544a17-20261001'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
strict=json.loads((b/'prefix-gpu-19cf258.json').read_text())
a=b/'prefix-gpu-19cf258.tar.gz';assert sha(a)==strict['archive_sha256']
prior=json.loads((v/'binding.json').read_text())
gate=json.loads((b/'sgi-tensor-control-source-prequalification/receipt.json').read_text())
assert gate['state']=='EXACT_TENSOR_CONTROL_DUAL90_AND_SASS_PASS'
old=json.loads((b/'sgi-reusable-serving-epochs-managed-aa8371f-complete-archive/receipt.json').read_text())
assert old['pass_numerical_epoch_smoke'] if 'pass_numerical_epoch_smoke' in old else old['archive_sha256']=='628c187620505549c94c5fe8a06265e11fe1c3533e6448b4ba80a8dc2f752e32'
p.mkdir()
with tarfile.open(a) as t:
 assert set(t.getnames())==set(strict['files'])
 for n,h in strict['files'].items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
 t.extractall(p,filter='data')
for n in ('runs','logs','receipts','sdk-libraries'):(p/n).mkdir()
for f in (v/'sdk-libraries').iterdir():shutil.copyfile(f,p/'sdk-libraries'/f.name)
for n in ('prefix_gpu_19cf258.sbatch','prepare_prefix_gpu_19cf258.py'):shutil.copyfile(b/n,p/n)
binding=dict(harness_commit=strict['harness_commit'],flashinfer_commit=prior['source_git_commit'],normal_wheel_sha256=prior['wheel_sha256'],source=prior['source'],source_ledger_sha256=prior['source_ledger_sha256'],source_files=strict['files'],vendor_git_pins=prior['vendor_git_pins'],scope='Already exposed BF16 page1 noncausal with real token-major packed/tuple KV views. Minimal metadata driver executes real Native plans; adapter+registry+router+public runner composition,3epochs36calls each. Not actual SGLang HTTP qualification.',fixed_calibration_attempts_per_geometry=1,managed_profiling_repeat=256,all_started_results_retained=True,actual_cache_and_resource_invocations_witnessed=True,request_time_training=False,resource_graph_metadata_updates_supported=False,full_http_qualified=False,fresh_cases_consumed=0,qualification_authority=False,default_promotion=False,serving_promotion=False,historical_token_divergence_resolved=False)
(p/'binding.json').write_text(json.dumps(binding,indent=2)+'\n')
(p/'validation.sha256').write_text(''.join(f'{sha(f)}  {f}\n' for f in sorted(p.rglob('*')) if f.is_file()))
jobs={}
for gpu in ('gpu_4090','gpu_5090'):
 jobs[gpu]=subprocess.check_output(['sbatch','--parsable','-p',gpu,'-o',str(p/'logs/%j.out'),'-e',str(p/'logs/%j.err'),str(p/'prefix_gpu_19cf258.sbatch'),str(p),prior['source']],text=True).strip()
 (p/'receipts/jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
print(json.dumps({'campaign':str(p),'jobs':jobs}))
