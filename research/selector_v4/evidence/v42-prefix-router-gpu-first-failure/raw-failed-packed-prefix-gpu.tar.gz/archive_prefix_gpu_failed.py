"""Retain both failed first attempts, including persisted managed cache."""
import hashlib
import json
import os
import subprocess
import tarfile
from pathlib import Path

b = Path('/ssd/scxi253')
p = b / 'sgi-prefix-router-gpu-19cf258-75544a17-20261001'
out = b / 'sgi-prefix-router-gpu-19cf258-failed-archive'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
jobs = json.loads((p / 'receipts/jobs.json').read_text())
statuses = {}
for gpu, job in jobs.items():
    statuses[gpu] = subprocess.check_output(['sacct', '-X', '-j', job, '--format=JobID,State,ExitCode,Elapsed', '-n'], text=True)
    assert 'FAILED' in statuses[gpu] and '1:0' in statuses[gpu]
    assert (p / f'receipts/exit-{job}.txt').read_text().strip() == '1'
    log = (p / f'logs/tests-{job}.log').read_text()
    assert '2 failed, 45 passed' in log and 'assert hit and index == 0 and cached == 1' in log
files = {}
for parent, dirs, names in os.walk(p):
    dirs[:] = [d for d in dirs if d not in ('cache', 'sdk-libraries', '__pycache__', '.pytest_cache')]
    for name in names:
        f = Path(parent) / name
        if f.is_file():
            files[str(f.relative_to(p))] = f
assert len([n for n in files if '/entries/' in n and n.endswith('.json')]) == 4
files[Path(__file__).name] = Path(__file__)
digests = {n: sha(f) for n, f in files.items()}
out.mkdir()
a = out / 'raw-failed-packed-prefix-gpu.tar.gz'
with tarfile.open(a, 'w:gz') as t:
    for n, f in sorted(files.items()):
        t.add(f, arcname=n, recursive=False)
with tarfile.open(a) as t:
    assert set(t.getnames()) == set(digests)
    for n, h in digests.items():
        assert hashlib.sha256(t.extractfile(n).read()).hexdigest() == h
receipt = dict(complete_archive_of_failed_attempt=True, pass_diagnostic=False, binding=json.loads((p/'binding.json').read_text()), statuses=statuses, jobs=jobs, root_cause='Cache witness omitted inputs=inputs; no complete runner certificate cache key. Witness fix requires a separate source-bound diagnostic.', persisted_managed_entries=4, certificate_receipts_complete=False, files=digests, archive_sha256=sha(a), archive_bytes=a.stat().st_size, qualification_authority=False, fresh_cases_consumed=0, full_http_resource_qualified=False, historical_token_divergence_resolved=False)
(out/'receipt.json').write_text(json.dumps(receipt, indent=2)+'\n')
print(json.dumps({k: receipt[k] for k in ('pass_diagnostic','archive_sha256','archive_bytes')}))
