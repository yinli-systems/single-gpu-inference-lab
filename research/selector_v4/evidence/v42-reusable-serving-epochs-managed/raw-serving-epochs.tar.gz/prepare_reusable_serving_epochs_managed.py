"""Dispatch only exposed functional ownership diagnostics on exact normal75544."""

import hashlib
import json
import shutil
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

b = Path('/ssd/scxi253')
p = b / 'sgi-reusable-serving-epochs-managed-aa8371f-75544a17-20261001'
v = b / 'sgi-official-wheel-validation-75544a17-20261001'
cpu = b / 'sgi-reusable-lease-cpu-20261001T1543Z'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
r = json.loads((cpu / 'receipt.json').read_text())
assert r['returncode'] == 0 and not r['gpu_execution']
assert sha(cpu / 'tests.log') == r['log_sha256']
assert sha(cpu / 'tests.xml') == r['xml_sha256']
suite = ET.parse(cpu / 'tests.xml').getroot().find('testsuite')
assert (suite.attrib['tests'], suite.attrib['skipped'], suite.attrib['failures'], suite.attrib['errors']) == ('8', '2', '0', '0')
gate = json.loads((b / 'sgi-tensor-control-source-prequalification/receipt.json').read_text())
assert gate['state'] == 'EXACT_TENSOR_CONTROL_DUAL90_AND_SASS_PASS'
prior = json.loads((v / 'binding.json').read_text())
assert prior['source_git_commit'] == r['flashinfer_commit']
strict = json.loads((b / 'reusable-lease-managed-aa8371f.json').read_text())
a = b / 'reusable-lease-managed-aa8371f.tar.gz'
assert sha(a) == strict['archive_sha256']
for name, expected in r['files'].items(): assert strict['files'][name] == expected
initial = json.loads((b / 'sgi-reusable-serving-epochs-568ccd2-complete-archive/receipt.json').read_text())
assert initial['pass_numerical_epoch_smoke']
p.mkdir()
with tarfile.open(a) as archive:
    assert set(archive.getnames()) == set(strict['files'])
    for name, expected in strict['files'].items():
        assert hashlib.sha256(archive.extractfile(name).read()).hexdigest() == expected
    archive.extractall(p, filter='data')
for n in ('runs', 'logs', 'receipts', 'sdk-libraries'): (p / n).mkdir()
for f in (v / 'sdk-libraries').iterdir(): shutil.copyfile(f, p / 'sdk-libraries' / f.name)
for n in ('reusable_serving_epochs_managed.sbatch', 'prepare_reusable_serving_epochs_managed.py'): shutil.copyfile(b / n, p / n)
binding = dict(harness_commit=strict['harness_commit'],
    flashinfer_commit=r['flashinfer_commit'], normal_wheel_sha256=prior['wheel_sha256'],
    source=prior['source'], source_ledger_sha256=prior['source_ledger_sha256'],
    source_files=strict['files'], vendor_git_pins=prior['vendor_git_pins'],
    cpu_receipt_sha256=sha(cpu / 'receipt.json'), initial_smoke_archive_sha256=initial['archive_sha256'], post_training_actual_cache_hit_and_resource_dispatch_witnesses=True, managed_artifacts_persisted=True,
    scope='Previously exposed BF16 ragged projection stride6144 and paged1 noncausal; explicit eager metadata epochs with actual confidence/v2 choice.',
    fixed_calibration_attempts_per_geometry=1, managed_profiling_repeat=256,
    metadata_update_epochs_per_accepted_certificate=3,
    all_started_results_retained=True, timing_scope='Descriptive transition wall cost only.',
    native_fallback_on_inconclusive_certificate_or_native_winner=True,
    resource_graph_metadata_updates_supported=False, full_http_qualified=False,
    fresh_cases_consumed=0, qualification_authority=False,
    default_promotion=False, serving_promotion=False, historical_token_divergence_resolved=False)
(p / 'binding.json').write_text(json.dumps(binding, indent=2)+'\n')
(p / 'validation.sha256').write_text(''.join(f'{sha(f)}  {f}\n' for f in sorted(p.rglob('*')) if f.is_file()))
jobs = {}
for gpu in ('gpu_4090','gpu_5090'):
    jobs[gpu] = subprocess.check_output(['sbatch', '--parsable', '-p', gpu,
        '-o', str(p / 'logs/%j.out'), '-e', str(p / 'logs/%j.err'),
        str(p / 'reusable_serving_epochs_managed.sbatch'), str(p), prior['source']], text=True).strip()
    (p / 'receipts/jobs.json').write_text(json.dumps(jobs, indent=2)+'\n')
print(json.dumps({'campaign':str(p), 'jobs':jobs}))
