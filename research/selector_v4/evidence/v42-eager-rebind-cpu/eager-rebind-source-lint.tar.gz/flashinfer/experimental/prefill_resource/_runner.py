# Copyright (c) 2026 by FlashInfer team.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

import copy
import ctypes
import os
import tempfile
import subprocess
import hashlib
import json
import inspect
import math
import time
from pathlib import Path

import torch
from filelock import FileLock

from flashinfer.autotuner import AutoTuner, TunableRunner, TuningConfig
from flashinfer.utils import PosEncodingMode
from ._policy import accepts, confidence_receipt


def compiler_options():
    return {
        name: os.environ.get(name)
        for name in (
            "CUDA_HOME",
            "CPATH",
            "NVCC_PREPEND_FLAGS",
            "NVCC_APPEND_FLAGS",
            "FLASHINFER_CUDA_ARCH_LIST",
            "FLASHINFER_JIT_DEBUG",
            "FLASHINFER_JIT_LINEINFO",
        )
    }


def input_stream(inputs):
    device = inputs[0].device
    return (
        torch.cuda.current_stream(device).cuda_stream if device.type == "cuda" else None
    )


def tensor_signature(tensor):
    return (
        tuple(tensor.shape),
        tuple(tensor.stride()),
        str(tensor.dtype),
        str(tensor.device),
    )


def option_signature(kwargs):
    return tuple(
        sorted(
            (
                name,
                tensor_signature(value)
                if isinstance(value, torch.Tensor)
                else repr(value),
            )
            for name, value in kwargs.items()
        )
    )


def cuda_driver_version():
    try:
        version = ctypes.c_int()
        status = ctypes.CDLL("libcuda.so.1").cuDriverGetVersion(ctypes.byref(version))
        return version.value if status == 0 else None
    except (OSError, AttributeError):
        return None


def tensor_version(tensor):
    try:
        return tensor._version
    except RuntimeError:
        return None


def plan_snapshot(wrapper):
    """Detect replanning, buffer replacement and ordinary in-place metadata updates."""
    return (
        tuple(wrapper._plan_info or ()),
        id(wrapper._plan_info),
        id(wrapper._cached_module),
        tuple(
            (
                name,
                (value.data_ptr(), tensor_signature(value)),
                0 if "workspace_buffer" in name else tensor_version(value),
            )
            for name, value in sorted(vars(wrapper).items())
            if isinstance(value, torch.Tensor)
            and (name.endswith("_buf") or "workspace_buffer" in name)
        ),
        tuple(
            (name, repr(getattr(wrapper, name, None)))
            for name in (
                "_causal",
                "_pos_encoding_mode",
                "_use_fp16_qk_reduction",
                "_window_left",
                "_logits_soft_cap",
                "_sm_scale",
                "_rope_scale",
                "_rope_theta",
                "_kv_layout",
            )
        ),
    )


class ResourceCapRunner(TunableRunner):
    """A runner for a prepared, immutable standard FA2 plan, with native fallback.

    Calls to ``calibrate`` explicitly run both tactics. Managed Autotuner v2
    can consider the cap only after the independent confidence gate passes.
    Cached tactic 1 is revalidated before every uncaptured invocation.
    """

    def __init__(
        self,
        wrapper,
        inputs,
        *,
        qo_lengths,
        kv_lengths,
        execution_mode,
        graph_replays,
        run_kwargs=None,
    ):
        from flashinfer.prefill import (
            BatchPrefillWithPagedKVCacheWrapper,
            BatchPrefillWithRaggedKVCacheWrapper,
        )

        if not isinstance(
            wrapper,
            (BatchPrefillWithPagedKVCacheWrapper, BatchPrefillWithRaggedKVCacheWrapper),
        ):
            raise TypeError("A planned standard prefill wrapper is required")
        if execution_mode not in ("eager_run", "graph_replay") or graph_replays not in (
            1,
            16,
        ):
            raise ValueError("Use eager_run or graph_replay with 1 or 16 replays")
        if execution_mode == "eager_run" and graph_replays != 1:
            raise ValueError("Eager execution has one invocation per sample")
        if len(inputs) != 3 or any(not isinstance(x, torch.Tensor) for x in inputs):
            raise ValueError("inputs must be [q, k, v], including unpacked paged K/V")
        self.wrapper = wrapper
        self.paged = isinstance(wrapper, BatchPrefillWithPagedKVCacheWrapper)
        self.execution_mode = execution_mode
        self.graph_replays = graph_replays
        self.qo_lengths = tuple(int(n) for n in qo_lengths)
        self.kv_lengths = tuple(int(n) for n in kv_lengths)
        if (
            not self.qo_lengths
            or len(self.qo_lengths) != len(self.kv_lengths)
            or any(
                q <= 0 or k <= 0 or (k < q and bool(getattr(wrapper, "_causal", True)))
                for q, k in zip(self.qo_lengths, self.kv_lengths, strict=True)
            )
        ):
            raise ValueError(
                "Positive query/KV lengths are required; causal KV must include the queries"
            )
        self.input_signatures = tuple(tensor_signature(x) for x in inputs)
        self.snapshot = plan_snapshot(wrapper)
        self._proxy = None
        self.receipt = None
        self._run_kwargs = dict(run_kwargs or {})
        self._run_options = option_signature(self._run_kwargs)
        self.source_id = None
        self._compiler_options = compiler_options()
        self._stream = input_stream(inputs)
        self._eligible = self._static_support(inputs)
        self.identity = self._identity(inputs)
        self.load_receipt()
        self.tuning_config = TuningConfig(
            use_cuda_graph=execution_mode == "graph_replay",
            cuda_graph_profile_replays=graph_replays,
        )

    @property
    def receipt(self):
        return copy.deepcopy(self._receipt)

    @receipt.setter
    def receipt(self, value):
        self._receipt = copy.deepcopy(value)
        self._receipt_valid = value is not None and accepts(value, self.identity)

    def _receipt_path(self, directory=None):
        from flashinfer.jit import env

        root = (
            Path(directory)
            if directory is not None
            else env.FLASHINFER_JIT_DIR / "experimental_resource_certificates"
        )
        return root / (self.identity + ".json")

    def load_receipt(self, directory=None):
        self.receipt = None
        try:
            self.receipt = json.loads(self._receipt_path(directory).read_text())
        except (OSError, ValueError, TypeError):
            self.receipt = None
        return self._receipt_valid

    def save_receipt(self, directory=None):
        if not self._receipt_valid:
            return False
        path = self._receipt_path(directory)
        temporary = None
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            with FileLock(str(path) + ".lock"):
                with tempfile.NamedTemporaryFile(
                    mode="w", dir=path.parent, delete=False
                ) as stream:
                    temporary = Path(stream.name)
                    json.dump(self._receipt, stream, sort_keys=True, allow_nan=False)
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(temporary, path)
                temporary = None
            return True
        except (OSError, ValueError):
            return False
        finally:
            if temporary is not None:
                temporary.unlink(missing_ok=True)

    def _static_support(self, inputs):
        w = self.wrapper
        from flashinfer.jit import env
        from ._jit import packaged_dependency_dirs, source_contract

        try:
            self.source_id = source_contract(
                env.FLASHINFER_INCLUDE_DIR,
                env.FLASHINFER_CSRC_DIR,
                packaged_dependency_dirs(env),
            )
            native = Path(inspect.getfile(type(w))).read_bytes()
            if (
                hashlib.sha256(native[:344213]).hexdigest()
                != "059a9dc01d652de9b7b70bbf6efecd736f6086e36f11941cd7eb972b5bbea006"
            ):
                return False
        except (OSError, ValueError):
            return False
        if cuda_driver_version() is None:
            return False
        return self._plan_support(inputs, self.snapshot)

    def _plan_support(self, inputs, snapshot):
        """Validate live plan geometry without repeating the frozen source audit."""
        if any(version is None for _, _, version in snapshot[3]):
            return False
        w = self.wrapper
        plan = getattr(w, "_plan_info", None)
        q, k, v = inputs
        if (
            w._backend != "fa2"
            or w._jit_module is not None
            or not plan
            or len(plan) != 15
            or plan[3] != 128
            or plan[14]
        ):
            return False
        if getattr(w, "_cached_o_data_type", None) not in (None, q.dtype):
            return False
        if (
            w._pos_encoding_mode != "NONE"
            or w._use_fp16_qk_reduction
            or w._window_left != -1
            or (w._logits_soft_cap or 0) != 0
        ):
            return False
        if any(
            getattr(w, name, None) is not None
            for name in (
                "_custom_mask_buf",
                "_prefix_len_ptr",
                "_token_pos_in_items_ptr",
                "_max_item_len_ptr",
                "_sinks",
            )
        ):
            return False
        if (
            q.device.type != "cuda"
            or any(
                x.device != q.device or x.dtype != q.dtype or x.shape[-1] != 128
                for x in inputs
            )
            or q.dtype not in (torch.float16, torch.bfloat16)
        ):
            return False
        if (
            q.ndim != 3
            or sum(self.qo_lengths) != q.shape[0]
            or tuple(k.stride()) != tuple(v.stride())
            or tuple(k.shape) != tuple(v.shape)
        ):
            return False
        if self.paged:
            if k.ndim != 4:
                return False
            kv_heads = k.shape[2 if w._kv_layout == "NHD" else 1]
            indptr = w._paged_kv_indptr_buf
            page_size = k.shape[1 if w._kv_layout == "NHD" else 2]
            # Verify supplied host geometry against the actual plan once, outside capture.
            actual_q = w._qo_indptr_buf.cpu().tolist()
            actual_pages = indptr.cpu().tolist()
            last = w._paged_kv_last_page_len_buf.cpu().tolist()
            actual_kv = tuple(
                (actual_pages[i + 1] - actual_pages[i] - 1) * page_size + last[i]
                for i in range(len(self.qo_lengths))
            )
        else:
            if k.ndim != 3:
                return False
            kv_heads = k.shape[1 if w._kv_layout == "NHD" else 0]
            indptr = w._kv_indptr_buf
            actual_q = w._qo_indptr_buf.cpu().tolist()
            actual = indptr.cpu().tolist()
            actual_kv = tuple(b - a for a, b in zip(actual, actual[1:], strict=False))
        if (
            tuple(b - a for a, b in zip(actual_q, actual_q[1:], strict=False))
            != self.qo_lengths
            or actual_kv != self.kv_lengths
            or kv_heads <= 0
            or q.shape[1] % kv_heads
        ):
            return False
        props = torch.cuda.get_device_properties(q.device)
        return (
            getattr(props, "shared_memory_per_multiprocessor", 0) >= 102400
            and getattr(props, "shared_memory_per_block_optin", 0) >= 65536
        )

    def _identity(self, inputs):
        backend = {
            p.name: hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(Path(__file__).parent.glob("*.py"))
        }
        environment = {
            "torch": torch.__version__,
            "cuda": torch.version.cuda,
            "compiler_options": self._compiler_options,
        }
        if inputs[0].device.type == "cuda":
            try:
                compiler = (
                    str(Path(os.environ["CUDA_HOME"]) / "bin/nvcc")
                    if "CUDA_HOME" in os.environ
                    else "nvcc"
                )
                environment["nvcc"] = subprocess.check_output(
                    [compiler, "--version"], text=True, timeout=10
                )
            except (OSError, subprocess.SubprocessError):
                environment["nvcc"] = None
        from flashinfer.jit import env

        backend["jit_generator"] = hashlib.sha256(
            (Path(env.__file__).parent / "attention/modules.py").read_bytes()
        ).hexdigest()
        backend["jit_compiler"] = hashlib.sha256(
            (Path(env.__file__).parent / "core.py").read_bytes()
        ).hexdigest()
        backend["jit_flags"] = hashlib.sha256(
            (Path(env.__file__).parent / "cpp_ext.py").read_bytes()
        ).hexdigest()
        # Bind the process module cache to its actual compiler/source envelope,
        # independently of per-plan shapes, certificates and physical GPU UUID.
        self.compilation_identity = hashlib.sha256(
            json.dumps(
                dict(
                    backend=backend, source_id=self.source_id, environment=environment
                ),
                sort_keys=True,
            ).encode()
        ).hexdigest()
        if inputs[0].device.type == "cuda":
            props = torch.cuda.get_device_properties(inputs[0].device)
            environment.update(
                driver=cuda_driver_version(),
                uuid=str(props.uuid),
                capability=torch.cuda.get_device_capability(inputs[0].device),
                name=props.name,
            )
        value = dict(
            backend=backend,
            source_id=self.source_id,
            native_python=hashlib.sha256(
                Path(inspect.getfile(type(self.wrapper))).read_bytes()
            ).hexdigest(),
            run_options=self._run_options,
            environment=environment,
            layout=self.paged,
            tensor_signatures=self.input_signatures,
            qo=self.qo_lengths,
            kv=self.kv_lengths,
            plan=self.snapshot[0],
            options=self.snapshot[4],
            execution_mode=self.execution_mode,
            graph_replays=self.graph_replays,
        )
        return hashlib.sha256(json.dumps(value, sort_keys=True).encode()).hexdigest()

    def rebind_same_geometry(self, inputs):
        """Explicitly bind a new eager native plan to an already certified runner.

        The caller exclusively owns planning/metadata and keeps the audited
        package/compiler files immutable for this runner's lifetime. This call
        verifies actual ordered query/KV metadata outside CUDA capture, reuses
        only an already loaded module and validated certificate, and never
        compiles, hashes source trees, reloads confidence or calibrates.

        Any rejection permanently disables resource execution on this runner.
        Construct a new runner to establish a different geometry/envelope.
        Graph runners require separate capture/metadata lifetime management and
        cannot use this eager-only operation.
        """
        try:
            snapshot = plan_snapshot(self.wrapper)
            valid = (
                self._eligible
                and self._receipt_valid
                and self._proxy is not None
                and self.execution_mode == "eager_run"
                and not torch.cuda.is_current_stream_capturing()
                and compiler_options() == self._compiler_options
                and input_stream(inputs) == self._stream
                and tuple(tensor_signature(x) for x in inputs) == self.input_signatures
                and option_signature(self._run_kwargs) == self._run_options
                and snapshot[0] == self.snapshot[0]
                and snapshot[2] == self.snapshot[2]
                and snapshot[4] == self.snapshot[4]
                and self._plan_support(inputs, snapshot)
            )
            if valid:
                module = self._proxy._cached_module
                proxy = copy.copy(self.wrapper)
                proxy._cached_module = module
                self._proxy = proxy
                self.snapshot = snapshot
                return True
        except (RuntimeError, ValueError, TypeError, AttributeError, IndexError):
            pass
        self._eligible = False
        return False

    def _current(self, inputs):
        return (
            self._eligible
            and self.snapshot == plan_snapshot(self.wrapper)
            and tuple(tensor_signature(x) for x in inputs) == self.input_signatures
        )

    def _native(self, inputs, **kwargs):
        q, k, v = inputs
        return (
            self.wrapper.run(q, (k, v), **kwargs)
            if self.paged
            else self.wrapper.run(q, k, v, **kwargs)
        )

    def _prepare(self, inputs):
        if self._proxy is None and self._current(inputs):
            if torch.cuda.is_current_stream_capturing():
                return False
            from ._ops import resource_module

            w = self.wrapper
            q, k, v = inputs
            indptr = w._paged_kv_indptr_buf if self.paged else w._kv_indptr_buf
            args = (
                q.dtype,
                k.dtype,
                getattr(w, "_cached_o_data_type", None) or q.dtype,
                indptr.dtype,
                128,
                128,
                PosEncodingMode[w._pos_encoding_mode].value,
                False,
                False,
                False,
            )
            try:
                module = resource_module(
                    *args,
                    source_id=self.source_id,
                    compilation_identity=self.compilation_identity,
                )
            except (
                RuntimeError,
                OSError,
                ValueError,
                TypeError,
                AttributeError,
            ) as error:
                self._eligible = False
                self._failure_reason = str(error)
                return False
            self._proxy = copy.copy(w)
            self._proxy._cached_module = module
        return self._proxy is not None

    def _resource(self, inputs, **kwargs):
        if not self._current(inputs):
            return self._native(inputs, **kwargs)
        if not self._prepare(inputs):
            return self._native(inputs, **kwargs)
        q, k, v = inputs
        return (
            self._proxy.run(q, (k, v), **kwargs)
            if self.paged
            else self._proxy.run(q, k, v, **kwargs)
        )

    def __hash__(self):
        return hash(
            (
                self.identity,
                self._receipt["checksum"] if self._receipt else "uncalibrated",
            )
        )

    def get_cache_key_extras(self, inputs):
        # Host geometry is frozen at construction; no synthesized tensor content
        # is inspected by managed autotuning. Certificates bind its cache epoch.
        return (
            self.identity,
            self._receipt["checksum"] if self._receipt else "uncalibrated",
        )

    def get_valid_tactics(self, inputs, profile):
        return [0, 1] if self._current(inputs) and self._receipt_valid else [0]

    def _dispatch(self, inputs, tactic, resource_authorized, kwargs):
        kwargs = {**self._run_kwargs, **kwargs}
        options = option_signature(kwargs)
        if (
            tactic == 1
            and resource_authorized
            and self._current(inputs)
            and options == self._run_options
        ):
            return self._resource(inputs, **kwargs)
        return self._native(inputs, **kwargs)

    def forward(self, inputs, tactic=-1, do_preparation=False, **kwargs):
        if do_preparation:
            self._prepare(inputs)
        return self._dispatch(inputs, tactic, self._receipt_valid, kwargs)

    def run(self, inputs, **kwargs):
        runner, tactic = AutoTuner.get().choose_one(
            "experimental_prefill_resource",
            [self],
            self.tuning_config,
            inputs,
            **kwargs,
        )
        return runner(inputs, tactic=tactic, **kwargs)

    def calibrate(self, inputs, *, blocks=32, window_ms=384, **kwargs):
        """Explicit ABBA/BAAB calibration on real inputs, outside CUDA capture.

        Graph mode times pure replay. This method does not certify metadata
        updates, full serving steps or untouched cross-GPU release shapes.
        """
        if blocks < 32 or blocks % 2 or window_ms < 384:
            raise ValueError("Use >=32 balanced blocks and >=384ms scored windows")
        if torch.cuda.is_current_stream_capturing():
            raise RuntimeError("Calibrate before graph capture")
        self.receipt = None
        if not self._current(inputs):
            self.receipt = confidence_receipt(self.identity, [], exact=False)
            return self.receipt
        if not self._prepare(inputs):
            self.receipt = confidence_receipt(self.identity, [], exact=False)
            return self.receipt
        kwargs = {**self._run_kwargs, **kwargs}
        if option_signature(kwargs) != self._run_options:
            raise ValueError("Construct a new runner for different run options")
        exact_kwargs = {**kwargs, "return_lse": True, "out": None, "lse": None}

        def snapshot(fn):
            return tuple(t.detach().clone() for t in fn(inputs, **exact_kwargs))

        native = snapshot(self._native)
        cap = snapshot(self._resource)
        after = snapshot(self._native)
        exact = all(
            torch.equal(a, b) and torch.equal(a, c)
            for a, b, c in zip(native, cap, after, strict=True)
        )
        if not exact:
            self.receipt = confidence_receipt(self.identity, [], exact=False)
            return self.receipt
        calls = [
            lambda: self._dispatch(inputs, 0, True, kwargs),
            lambda: self._dispatch(inputs, 1, True, kwargs),
        ]
        graphs = []
        if self.execution_mode == "graph_replay":
            for call in calls:
                for _ in range(3):
                    call()
                torch.cuda.synchronize()
                graph = torch.cuda.CUDAGraph()
                with torch.cuda.graph(graph):
                    for _ in range(self.graph_replays):
                        call()
                graphs.append(graph)
            calls = [graph.replay for graph in graphs]

        def measure(call, repeats):
            if self.execution_mode == "eager_run":
                torch.cuda.current_stream().synchronize()
                start_ns = time.perf_counter_ns()
                for _ in range(repeats):
                    call()
                torch.cuda.current_stream().synchronize()
                return (time.perf_counter_ns() - start_ns) / 1e6
            start, end = (
                torch.cuda.Event(enable_timing=True),
                torch.cuda.Event(enable_timing=True),
            )
            start.record()
            for _ in range(repeats):
                call()
            end.record()
            end.synchronize()
            return start.elapsed_time(end)

        # A shared pristine pilot fixes window counts for both tactics.
        pilot = measure(calls[0], 8)
        repeats = max(8, math.ceil(window_ms / max(pilot / 8, 1e-6)))
        rows = []
        for block in range(blocks):
            row = [None] * 4
            order = (0, 1, 2, 3) if block % 2 == 0 else (1, 0, 3, 2)
            for slot in order:
                row[slot] = (
                    measure(calls[0 if slot in (0, 3) else 1], repeats) / repeats
                )
            rows.append(row)
        self.receipt = confidence_receipt(self.identity, rows, exact=exact)
        self.save_receipt()
        return self.receipt
