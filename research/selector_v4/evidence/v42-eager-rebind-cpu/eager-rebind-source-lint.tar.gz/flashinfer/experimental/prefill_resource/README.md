# Prepared FA2 resource-cap runner (experimental)

Owner: @yinli-systems. Proposed lifecycle review: 2026-10-29. Tracking issue and
maintainer-approved target release must be linked before submitting the PR.
Graduation target: the next 0.7.x release after native transparency, independent
cross-GPU holdouts, full serving boundaries and token parity qualify. Otherwise
retain explicit incubation with maintainer approval or remove the feature.

The API and backend are experimental. This is a prepared-plan runner/calibration
contract, rather than a new attention operation. Calling
`flashinfer.prefill.make_prefill_resource_runner` is the explicit opt-in and emits
an ExperimentalWarning. Stable attention APIs never automatically select it.
The environment flag for experimental automatic backends does not change this.
The native wrapper, 15-field planner, dispatcher and kernel sources are unchanged.

The resource backend constructs a private JIT module from reviewed, hash-bound
FA2 sources. Cold identity checks also hash the packaged CCCL, CUTLASS and
spdlog include trees, including extensionless C++ headers; missing, empty or
cyclic trees reject the resource tactic. Changed vendor headers invalidate both
the private JIT URI and confidence-cache identity. External compiler options
remain part of the environment binding. Its distinct ragged/paged kernels have the original compute body;
only the resource dispatcher raises dynamic shared-memory allocation from
49,152 to 65,536 bytes. The extra allocation is capacity padding and is never
read as attention state. Native generated sources and libraries are never
patched. No AOT entry is registered.

The in-process resource-module cache also binds the compiler/source envelope.
A new runner observing changed headers or compiler settings cannot borrow an
old loaded module for the same dtype/shape template: preparation rejects the
resource path and retains native. Restart with a verified source and private JIT
cache to qualify a changed compiler envelope; hot-swapping loaded native/resource
operators is unsupported. Source changes between identity and first preparation
also reject the resource path. Keep compiler/package files immutable while a
process executes or builds its prepared plans.

Supported scope is deliberately narrow: standard FA2, FP16/BF16 Q/K/V/output,
D128, CTA128, unsplit plans, no positional encoding/sliding window/custom mask,
no logits soft cap or FP16 QK reduction, sufficient SM and block shared memory,
and matching K/V strides. Supply `[q, k, v]` for either layout, including
unpacked paged K/V. The supplied ordered query/KV lengths are checked against
actual plan metadata at construction outside graph capture. Unsupported plans
retain the native fallback.

Noncausal prefix attention can have fewer cached KV tokens than query tokens,
as in a serving system that separately computes the causal suffix attention.
Positive query/KV lengths are supported in that case. Causal plans still require
KV lengths to include their queries. This geometry support alone does not
qualify the serving system's combination of prefix and suffix attention.

A runner belongs to one frozen plan and input geometry. Construct a new runner
when geometry or the source/compiler envelope changes. Ordinary tensor metadata updates, buffer replacement and
new plan generations invalidate the old runner. Inference tensors lacking
version counters are conservatively unsupported. External raw-pointer writes
cannot be tracked; the caller must preserve the frozen-plan contract. Concurrent
planning/execution on one wrapper is unsupported, as in the native wrapper.
Scratch workspace writes are expected during execution; their pointers and
geometry remain bound, while version counters are checked only for plan metadata.

For exclusively owned eager plans of the same ordered geometry, explicitly call
`runner.rebind_same_geometry(inputs)` after the new native `plan` and before
execution. This opt-in checks the actual query/KV metadata, all 15 planner values,
native module, options, tensor shapes/strides/dtypes/device, CUDA stream and
compiler options. It reuses only an already loaded resource module and accepted
in-memory confidence certificate. It performs no source-tree scan, compiler
subprocess, confidence reload/bootstrap, JIT compilation or recalibration.
Package/compiler files must remain immutable for the prepared runner's lifetime,
as for its ordinary execution. Any rejection permanently disables its resource
path; use native or construct a new runner for a different envelope. Rebinding
is outside capture and is unsupported for Graph runners. This method alone does
not qualify per-plan costs, changing serving metadata, or end-to-end HTTP.

`calibrate` is an explicit operation outside graph capture. It first compares
native/resource/native output and LSE exactly, then retains every observation in
at least 32 balanced ABBA/BAAB blocks with a 384 ms target window fixed by a
shared native pilot. Resource selection requires >=5% geometric-mean gain,
95% lower confidence bound >=1.01, every treatment block >=0.99, and both
90% duplicate-control intervals within +/-0.5%. No observations are trimmed.
Unknown, corrupt, stale, mismatched and inconclusive receipts select native.
Accepted receipts are published atomically under the source/device-bound JIT
cache. Reload recomputes every gate from raw measurements; the hot path checks
the already-validated immutable certificate and current plan identity.

The runner implements TunableRunner. Use `autotune_v2(mode="tune")` with
`MeasurementPolicy(execution_mode="eager")` or `"cuda_graph"` matching the
runner, then `autotune_v2(mode="replay")` with the same policy for serving.
`runner.run` delegates to the shared tuner; the v2 context manages persistence.
The example checks that actual profiling produced a winner and no offered
tactic failed profiling. Managed v2 also profiles the default native tactic -1;
a measured default winner is valid, while an unprofiled fallback is not.
Until calibration qualifies, only native is offered; stale cap
cache entries still fall back. Keys bind the backend source, actual GPU UUID,
CUDA driver/runtime, Torch, ordered geometry, plan configuration, execution
mode, graph replay count and confidence certificate. `run_kwargs` are frozen
at construction. Changing invocation options falls back to native.

`eager_run` uses synchronized wall time for the preplanned Python wrapper call,
including recurring host overhead. `graph_replay` measures
pure replay with 1 or 16 captured runs. Neither result measures replanning,
input/metadata updates, a full serving step or end-to-end HTTP performance.
Calibration within one process is not independent-process release evidence.
The separate research qualification campaign provides those additional gates;
its 0.7-baseline measurements do not certify this main-branch port. Historical
2/432 serving token divergences remain a separate unresolved blocker to default
or supported serving integration.

Run `python examples/experimental/prefill_resource.py`. CPU and GPU tests live
under `tests/experimental/prefill_resource/`, outside stable CI lanes.
