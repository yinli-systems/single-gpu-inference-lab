# Copyright (c) 2026 by FlashInfer team.
# Licensed under the Apache License, Version 2.0.
from unittest.mock import patch

import pytest

torch = pytest.importorskip("torch")
from flashinfer.prefill import (
    BatchPrefillWithPagedKVCacheWrapper,
    BatchPrefillWithRaggedKVCacheWrapper,
    make_prefill_resource_runner,
)

pytestmark = pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA required")


@pytest.mark.parametrize("dtype", [torch.float16, torch.bfloat16])
@pytest.mark.parametrize("paged", [False, True])
def test_same_geometry_replanning_and_metadata_replacement(dtype, paged):
    """Functional module/plan checks with a mocked gate, never a timing certificate."""
    torch.manual_seed(42)
    q = torch.randn(512, 32, 128, dtype=dtype, device="cuda")
    k = torch.randn(4096, 8, 128, dtype=dtype, device="cuda")
    v = torch.randn_like(k)
    workspace = torch.empty(128 << 20, dtype=torch.uint8, device="cuda")
    qi = torch.tensor([0, 512], dtype=torch.int32, device="cuda")
    ki = torch.tensor([0, 4096], dtype=torch.int32, device="cuda")
    indices = torch.arange(4096, dtype=torch.int32, device="cuda")
    last = torch.ones(1, dtype=torch.int32, device="cuda")
    kwargs = dict(causal=True, q_data_type=dtype, disable_split_kv=True)
    if paged:
        wrapper = BatchPrefillWithPagedKVCacheWrapper(workspace, backend="fa2")
        inputs = [q, k.unsqueeze(1), v.unsqueeze(1)]
        plan = lambda: wrapper.plan(qi, ki, indices, last, 32, 8, 128, 1, **kwargs)
        native = lambda: wrapper.run(q, (k, v), return_lse=True)
    else:
        wrapper = BatchPrefillWithRaggedKVCacheWrapper(workspace, backend="fa2")
        inputs = [q, k, v]
        plan = lambda: wrapper.plan(qi, ki, 32, 8, 128, **kwargs)
        native = lambda: wrapper.run(q, k, v, return_lse=True)
    plan()
    runner = make_prefill_resource_runner(
        wrapper, inputs, qo_lengths=[512], kv_lengths=[4096]
    )
    assert runner._eligible and runner._prepare(inputs)
    module = runner._proxy._cached_module
    original_identity = runner.identity
    for _iteration in range(3):
        # New metadata objects and plan generations; payload/page mapping can change.
        qi, ki = qi.clone(), ki.clone()
        if paged:
            indices = indices.roll(7)
            last = last.clone()
        q.copy_(torch.randn_like(q))
        plan()
        assert not runner._current(inputs)
        expected = tuple(t.clone() for t in native())
        with patch.object(runner, "_receipt_valid", True):
            assert runner.rebind_same_geometry(inputs)
            assert runner._current(inputs)
            actual = runner._resource(inputs, return_lse=True)
            for value, reference in zip(actual, expected, strict=True):
                torch.testing.assert_close(value, reference, rtol=0, atol=0)
            torch.testing.assert_close(
                runner.forward(inputs, tactic=1), expected[0], rtol=0, atol=0
            )
        assert runner.identity == original_identity
        assert runner._proxy._cached_module is module
    # Same-sized but changed logical geometry must permanently reject reuse.
    qi[-1] = 511
    with patch.object(runner, "_receipt_valid", True):
        assert not runner.rebind_same_geometry(inputs)
    assert not runner._eligible
    assert runner.get_valid_tactics(inputs, None) == [0]
