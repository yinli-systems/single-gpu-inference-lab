# Copyright (c) 2026 by FlashInfer team.
# Licensed under the Apache License, Version 2.0.
import copy
from unittest.mock import patch

import pytest

torch = pytest.importorskip("torch")
from test_runner import certify, make_runner


def prepared():
    runner, inputs = make_runner()
    runner._eligible = True
    certify(runner)
    runner._proxy = copy.copy(runner.wrapper)
    return runner, inputs


def rebind(runner, inputs):
    with (
        patch.object(torch.cuda, "is_current_stream_capturing", return_value=False),
        patch.object(runner, "_plan_support", return_value=True),
    ):
        return runner.rebind_same_geometry(inputs)


def test_same_geometry_new_generation_reuses_module_and_validated_receipt():
    runner, inputs = prepared()
    key = runner.get_cache_key_extras(inputs)
    old_proxy = runner._proxy
    module = old_proxy._cached_module
    runner.wrapper._plan_info = list(runner.wrapper._plan_info)
    assert runner.forward(inputs, tactic=1) == "native"
    with (
        patch.object(runner, "_identity", side_effect=AssertionError("cold identity")),
        patch.object(runner, "load_receipt", side_effect=AssertionError("reload")),
        patch(
            "flashinfer.experimental.prefill_resource._runner.accepts",
            side_effect=AssertionError("bootstrap"),
        ),
        patch(
            "flashinfer.experimental.prefill_resource._jit.source_contract",
            side_effect=AssertionError("source scan"),
        ),
    ):
        assert rebind(runner, inputs)
    assert runner._proxy is not old_proxy
    assert runner._proxy._cached_module is module
    assert runner._proxy._plan_info is runner.wrapper._plan_info
    assert runner.get_cache_key_extras(inputs) == key
    assert runner.forward(inputs, tactic=1) == "resource"


@pytest.mark.parametrize(
    "change",
    ["plan", "module", "options", "input", "receipt", "proxy", "mode", "compiler"],
)
def test_rebind_rejections_are_sticky_and_native(change, monkeypatch):
    runner, inputs = prepared()
    if change == "plan":
        runner.wrapper._plan_info[0] += 1
    elif change == "module":
        runner.wrapper._cached_module = object()
    elif change == "options":
        runner.wrapper._window_left = 127
    elif change == "input":
        inputs[0] = inputs[0][:64]
    elif change == "receipt":
        runner.receipt = None
    elif change == "proxy":
        runner._proxy = None
    elif change == "mode":
        runner.execution_mode = "graph_replay"
    else:
        monkeypatch.setenv("NVCC_APPEND_FLAGS", "-DREBIND_CHANGED=1")
    assert not rebind(runner, inputs)
    assert not runner._eligible
    assert runner.forward(inputs, tactic=1) == "native"
    assert runner.get_valid_tactics(inputs, None) == [0]
    assert not rebind(runner, inputs)


@pytest.mark.parametrize("failure", ["metadata", "capture", "stream", "exception"])
def test_rebind_runtime_boundary_rejects(failure):
    runner, inputs = prepared()
    with (
        patch.object(
            torch.cuda, "is_current_stream_capturing", return_value=failure == "capture"
        ),
        patch(
            "flashinfer.experimental.prefill_resource._runner.input_stream",
            return_value=99 if failure == "stream" else None,
        ),
        patch.object(
            runner,
            "_plan_support",
            return_value=failure != "metadata",
            side_effect=RuntimeError("unreadable metadata")
            if failure == "exception"
            else None,
        ),
    ):
        assert not runner.rebind_same_geometry(inputs)
    assert not runner._eligible and runner.forward(inputs, tactic=1) == "native"
