"""Build metadata for flashinfer package."""
__version__ = "0.7.1"
__git_commit__ = "75544a17ce0019ca877f50354d95451ee089f859"
