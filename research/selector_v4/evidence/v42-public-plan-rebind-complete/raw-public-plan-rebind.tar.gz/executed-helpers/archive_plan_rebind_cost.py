"""Lossless archive of completed public setup diagnosis, without qualification."""

import hashlib
import json
import subprocess
import tarfile
from pathlib import Path


base = Path('/ssd/scxi253')
campaign = base / 'sgi-public-plan-rebind-58da590-d3d080ce-20261001'
out = base / 'sgi-public-plan-rebind-complete-archive'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
summary = json.loads((campaign / 'analysis-complete/summary.json').read_text())
assert summary['all32_observations_per_gpu_retained']
assert not summary['qualification_authority']
for gpu, record in summary['gpus'].items():
    status = subprocess.check_output(
        ['sacct', '-j', record['job'], '--format=JobID,State,ExitCode,Elapsed', '-n', '-X'],
        text=True,
    )
    assert 'COMPLETED' in status and '0:0' in status, status
    assert record['observations'] == 32 and record['all_output_exact']
for name, digest in summary['input_files_sha256'].items():
    assert sha(campaign / name) == digest, name
source = Path(summary['binding']['source'])
verification = subprocess.run(['sha256sum', '-c', 'source.sha256'], cwd=source,
                              capture_output=True, text=True, check=True)
out.mkdir()
(out / 'source-final-verification.txt').write_text(verification.stdout)
files = {str(p.relative_to(campaign)): p for p in campaign.rglob('*')
         if p.is_file() and not p.is_relative_to(campaign / 'cache')}
for name in ('analyze_plan_rebind_cost.py', 'archive_plan_rebind_cost.py',
             'finalize_eager_rebind_source.py'):
    files['executed-helpers/' + name] = base / name
for p in (base / 'sgi-eager-rebind-source-prequalification').rglob('*'):
    if p.is_file():
        files['source-prequalification/' + str(p.relative_to(base / 'sgi-eager-rebind-source-prequalification'))] = p
ledger = {name: sha(p) for name, p in sorted(files.items())}
archive = out / 'raw-public-plan-rebind.tar.gz'
with tarfile.open(archive, 'w:gz') as t:
    for name, p in sorted(files.items()):
        t.add(p, arcname=name, recursive=False)
with tarfile.open(archive) as t:
    assert {m.name for m in t.getmembers() if m.isfile()} == set(ledger)
    for name, digest in ledger.items():
        assert hashlib.sha256(t.extractfile(name).read()).hexdigest() == digest
receipt = dict(complete=True, binding=summary['binding'], files=ledger,
               archive_sha256=sha(archive), archive_bytes=archive.stat().st_size,
               summary_sha256=sha(campaign / 'analysis-complete/summary.json'),
               source_final_verification_sha256=sha(out / 'source-final-verification.txt'),
               fresh_cases_consumed=0, qualification_authority=False,
               default_promotion=False, serving_promotion=False,
               historical_token_divergence_resolved=False)
(out / 'receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ('complete', 'archive_bytes', 'archive_sha256')}))
