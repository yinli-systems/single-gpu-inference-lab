"""Retain all first results of the corrected real GPU composition witness."""
import hashlib
import json
import os
import subprocess
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

b = Path('/ssd/scxi253')
p = b / 'sgi-prefix-router-gpu-d42fe43-75544a17-20261001'
out = b / 'sgi-prefix-router-gpu-d42fe43-complete-archive'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
jobs = json.loads((p/'receipts/jobs.json').read_text())
results = {}
for gpu, job in jobs.items():
    status = subprocess.check_output(['sacct','-X','-j',job,'--format=JobID,State,ExitCode,Elapsed','-n'],text=True)
    assert 'COMPLETED' in status and '0:0' in status
    assert (p/f'receipts/exit-{job}.txt').read_text().strip() == '0'
    suite = ET.parse(p/f'receipts/tests-{job}.xml').getroot().find('testsuite')
    assert int(suite.attrib['tests']) == 47 and all(int(suite.attrib.get(n,0)) == 0 for n in ('failures','errors','skipped'))
    formats = {}
    for label in ('packed','tuple'):
        root = p/f'runs/{gpu}-{job}'
        x = json.loads((root/(label+'.json')).read_text())
        first = json.loads((root/(label+'-training.json')).read_text())
        assert first['certificate'] == x['certificate'] and first['actual_managed_tactic'] == x['actual_managed_tactic']
        assert x['native_graph_payload_update_exact'] and x['native_unpack_used']
        assert len(x['epochs']) == 3
        expected = 36 if x['actual_managed_tactic'] == 1 else 0
        for epoch in x['epochs']:
            assert epoch['full_output_lse_exact'] and epoch['late_metadata_binding_forbidden']
            assert epoch['actual_resource_calls'] == expected
            assert epoch['actual_managed_cache_hits'] == [1]*expected
        formats[label] = x
    results[gpu] = dict(sacct=status, tests=47, formats=formats)
files = {}
for parent, dirs, names in os.walk(p):
    dirs[:] = [d for d in dirs if d not in ('cache','sdk-libraries','__pycache__','.pytest_cache')]
    for n in names:
        f = Path(parent)/n
        if f.is_file():files[str(f.relative_to(p))] = f
files[Path(__file__).name] = Path(__file__)
digests = {n:sha(f) for n,f in files.items()}
out.mkdir();a = out/'raw-packed-prefix-gpu-composition.tar.gz'
with tarfile.open(a,'w:gz') as t:
    for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
with tarfile.open(a) as t:
    assert set(t.getnames()) == set(digests)
    for n,h in digests.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest() == h
receipt = dict(pass_numerical_composition=True,binding=json.loads((p/'binding.json').read_text()),jobs=jobs,results=results,files=digests,archive_sha256=sha(a),archive_bytes=a.stat().st_size,actual_resource_calls=sum(e['actual_resource_calls'] for x in results.values() for f in x['formats'].values() for e in f['epochs']),scope='Minimal driver executes real Native plan; not SGLang full HTTP',qualification_authority=False,fresh_cases_consumed=0,full_http_resource_qualified=False,resource_graph_metadata_updates_supported=False,historical_token_divergence_resolved=False)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('pass_numerical_composition','actual_resource_calls','archive_sha256','archive_bytes')}))
