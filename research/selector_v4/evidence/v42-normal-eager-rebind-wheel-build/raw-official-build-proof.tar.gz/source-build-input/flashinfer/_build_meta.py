"""Build metadata for flashinfer package."""
__version__ = "0.7.1"
__git_commit__ = "d3d080ce36bf074136d4b2093b775a8cb1d7dfc5"
