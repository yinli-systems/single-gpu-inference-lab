"""Only two exposed dev cases; exact normal packages and handoff prerequisite."""

import hashlib
import json
import shutil
import subprocess
import zipfile
from pathlib import Path

from public_path_contract import CONTRACT

b = Path('/ssd/scxi253')
h = Path(__file__).resolve().parent
candidate = '75544a17ce0019ca877f50354d95451ee089f859'
pristine = '85744da1a397c0c4bea1a83b8345281750eb61a9'
harness = (h / 'public_path_harness_commit.txt').read_text().strip()
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
v = b / 'sgi-official-wheel-validation-75544a17-20261001'
gate = json.loads((b / 'sgi-tensor-control-source-prequalification/receipt.json').read_text())
assert gate['terminal'] and gate['state'] == 'EXACT_TENSOR_CONTROL_DUAL90_AND_SASS_PASS'
assert gate['source_commit'] == candidate
handoff_gate = json.loads((b / 'sgi-tensor-control-process-handoff-strict-gate/receipt.json').read_text())
assert handoff_gate['terminal'] and handoff_gate['state'] == 'CROSS_PROCESS_FUNCTIONAL_JOBS_DISPATCHED'
handoff = b / 'sgi-public-process-handoff-6aaa0b9-75544a17-20261001'
handoff_jobs = json.loads((handoff / 'receipts/jobs.json').read_text())
for gpu, job in handoff_jobs.items():
    assert (handoff / f'receipts/exit-{job}.txt').read_text().strip() == '0'
    for role in ('producer', 'consumer1', 'consumer2'):
        root = handoff / f'runs/{gpu}-{job}/{role}'
        assert json.loads((root / 'complete.json').read_text())['pass']
        env = json.loads((root / 'environment.json').read_text())
        assert env['source_commit'] == candidate
        assert env['calibrates_and_tunes'] == (role == 'producer')
cb = b / f'sgi-flashinfer-official-build-{candidate[:8]}-20261001'
pb = b / f'sgi-flashinfer-official-build-{pristine[:8]}-20261001'
c = json.loads((cb / 'receipt.json').read_text())
p = json.loads((pb / 'receipt.json').read_text())
for receipt, expected in ((c, candidate), (p, pristine)):
    assert receipt['build_pass'] and receipt['source_git_commit'] == expected
    assert receipt['normal_upstream_hook'] and receipt['all_non_generated_wheel_package_bytes_match_prebuild_source_ledger']
    assert sha(Path(receipt['wheel'])) == receipt['wheel_sha256']
assert c['vendor_git_pins'] == p['vendor_git_pins']
ledger = {}
with zipfile.ZipFile(c['wheel']) as cz, zipfile.ZipFile(p['wheel']) as pz:
    native_names = {n for n in pz.namelist() if n.startswith('flashinfer/') and not n.endswith('/')}
    assert native_names <= set(cz.namelist())
    for name in sorted(native_names - {'flashinfer/prefill.py', 'flashinfer/_build_meta.py'}):
        native = pz.read(name)
        assert cz.read(name) == native, name
        ledger[name] = hashlib.sha256(native).hexdigest()
    original = pz.read('flashinfer/prefill.py')
    assert len(original) == 344213
    assert cz.read('flashinfer/prefill.py')[:len(original)] == original
    ledger['flashinfer/prefill.py:native-prefix'] = hashlib.sha256(original).hexdigest()
out = b / f'sgi-public-path-prequal-{harness[:7]}-75544a17-20261001'
out.mkdir()
for name in ('logs', 'runs', 'receipts', 'sdk-libraries'):
    (out / name).mkdir()
for name in ('public_path_contract.py', 'public_path_prequal.py', 'public_path_prequal.sbatch', 'analyze_public_path_prequal.py', 'audit_public_path_sass.py', 'audit_main_sass.py'):
    shutil.copyfile(h / name, out / name)
ps = out / 'pristine-overlay'
ps.mkdir()
with zipfile.ZipFile(p['wheel']) as archive:
    archive.extractall(ps)
for name in ('include', 'csrc'):
    (ps / name).symlink_to(ps / 'flashinfer/data' / name, target_is_directory=True)
source_ledger = ps / 'source.sha256'
source_ledger.write_text(''.join(f'{sha(f)}  {f.relative_to(ps)}\n' for f in sorted(ps.rglob('*')) if f.is_file()))
for file in (v / 'sdk-libraries').iterdir():
    shutil.copyfile(file, out / 'sdk-libraries' / file.name)
cases = json.loads((h / 'public_path_exposed_cases.json').read_text())
assert len(cases) == 2 and all(x['family'] == 'dev' and x['exposed_development'] for x in cases)
binding = {
    'candidate_commit': candidate, 'pristine_commit': pristine, 'harness_commit': harness,
    'candidate_wheel_sha256': c['wheel_sha256'], 'pristine_wheel_sha256': p['wheel_sha256'],
    'candidate_source': str(v / 'wheel-overlay'), 'pristine_source': str(ps),
    'candidate_build_receipt_sha256': sha(cb / 'receipt.json'), 'pristine_build_receipt_sha256': sha(pb / 'receipt.json'),
    'candidate_source_ledger_sha256': sha(v / 'wheel-overlay/source.sha256'), 'pristine_source_ledger_sha256': sha(source_ledger),
    'vendor_git_pins': c['vendor_git_pins'], 'native_common_package_files_sha256': ledger,
    'normal90_sass_receipt_sha256': sha(b / 'sgi-tensor-control-source-prequalification/receipt.json'),
    'cases': cases, 'contract': CONTRACT, 'contract_sha256': sha(h / 'public_path_contract.py'),
    'handoff_jobs': handoff_jobs, 'fresh_cases_consumed': 0, 'qualification_authority': False,
    'default_promotion': False, 'serving_promotion': False, 'historical_token_divergence_resolved': False,
}
(out / 'binding.json').write_text(json.dumps(binding, indent=2) + '\n')
(out / 'validation.sha256').write_text(''.join(f'{sha(f)}  {f}\n' for f in sorted(out.rglob('*')) if f.is_file() and ps not in f.parents))
jobs = {}
for gpu in ('gpu_4090', 'gpu_5090'):
    jobs[gpu] = {}
    for index in (0, 1):
        job = subprocess.check_output(['sbatch', '--parsable', '-p', gpu, '-o', str(out / 'logs/%j.out'), '-e', str(out / 'logs/%j.err'), str(out / 'public_path_prequal.sbatch'), str(out), binding['candidate_source'], str(index), str(ps)], text=True).strip()
        jobs[gpu][str(index)] = job
        (out / 'receipts/jobs.json').write_text(json.dumps(jobs, indent=2) + '\n')
print(json.dumps({'campaign': str(out), 'jobs': jobs, 'fresh_cases_consumed': 0}))
