"""Finite handoff gate; may dispatch only the two exposed development cases."""

import datetime
import hashlib
import json
import subprocess
import time
from pathlib import Path

b = Path('/ssd/scxi253')
h = Path(__file__).resolve().parent
p = b / 'sgi-public-path-prequalification-gate-c6879fb'
p.mkdir()
e = b / 'q7b-engines-20260925T1247Z/envs/sglang312/bin/python'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
helpers = ['prepare_public_path_prequal.py', 'public_path_prequal.py', 'public_path_contract.py', 'public_path_prequal.sbatch', 'public_path_exposed_cases.json', 'public_path_harness_commit.txt', 'analyze_public_path_prequal.py', 'audit_public_path_sass.py', 'audit_main_sass.py']
s = dict(state='WAIT_EXACT_SOURCE_AND_CROSS_PROCESS_HANDOFF', helpers={n: sha(h / n) for n in helpers}, fresh_cases_consumed=0, release_consumed=0, stress_consumed=0, default_promotion=False, serving_promotion=False, qualification_authority=False)


def save():
    s['updated_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    tmp = p / 'receipt.tmp'
    tmp.write_text(json.dumps(s, indent=2) + '\n')
    tmp.replace(p / 'receipt.json')


save()
try:
    deadline = time.monotonic() + 20000
    handoff = b / 'sgi-public-process-handoff-6aaa0b9-75544a17-20261001'
    gate = b / 'sgi-tensor-control-process-handoff-strict-gate/receipt.json'
    while not (handoff / 'receipts/jobs.json').exists():
        if gate.exists():
            r = json.loads(gate.read_text())
            assert not (r.get('terminal') and r['state'] != 'CROSS_PROCESS_FUNCTIONAL_JOBS_DISPATCHED'), r
        if time.monotonic() > deadline:
            raise TimeoutError('Finite source/handoff dispatch deadline')
        time.sleep(15)
    jobs = json.loads((handoff / 'receipts/jobs.json').read_text())
    assert len(jobs) == 2
    s['handoff_jobs'] = jobs
    save()
    while True:
        done = []
        for job in jobs.values():
            f = handoff / f'receipts/exit-{job}.txt'
            if f.exists():
                assert f.read_text().strip() == '0', str(f)
                done.append(job)
            else:
                status = subprocess.check_output(['sacct', '-j', job, '--format=State', '-n', '-X'], text=True)
                assert not any(x in status for x in ('FAILED', 'CANCELLED', 'TIMEOUT', 'NODE_FAIL', 'OUT_OF_MEMORY')), status
        if len(done) == 2:
            break
        if time.monotonic() > deadline:
            raise TimeoutError('Finite independent-consumer deadline')
        time.sleep(15)
    for name, expected in s['helpers'].items():
        assert sha(h / name) == expected, name
    with (p / 'preparation.log').open('w') as log:
        subprocess.run([str(e), str(h / 'prepare_public_path_prequal.py')], check=True, stdout=log, stderr=subprocess.STDOUT, timeout=2400)
    root = b / 'sgi-public-path-prequal-c6879fb-75544a17-20261001'
    s.update(state='TWO_EXPOSED_PUBLIC_PATH_DEV_CASES_DISPATCHED', terminal=True, campaign=str(root), jobs=json.loads((root / 'receipts/jobs.json').read_text()))
    save()
except BaseException as ex:
    s.update(state='PUBLIC_PATH_PREQUAL_HOLD', terminal=True, error=dict(type=type(ex).__name__, message=str(ex)))
    save()
    raise
print(json.dumps(s))
