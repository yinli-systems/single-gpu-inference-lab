"""Dispatch the fixed exposed rebind cost diagnosis after exact dual86/SASS."""
import hashlib
import json
import shutil
import subprocess
from pathlib import Path

base = Path('/ssd/scxi253')
commit = '75544a17ce0019ca877f50354d95451ee089f859'
validation = base / 'sgi-official-wheel-validation-75544a17-20261001'
out = base / 'sgi-public-process-handoff-dbc27f6-75544a17-20261001'
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
for job in json.loads((validation / 'receipts/jobs.json').read_text()).values():
    assert (validation / f'receipts/exit-{job}.txt').read_text().strip() == '0'
    assert json.loads((validation / f'modes-{job}/summary.json').read_text())['pass']
for gpu in ('gpu_4090', 'gpu_5090'):
    audit = json.loads((base / ('sgi-official-wheel-tensor-control-sass-' + gpu) / 'receipt.json').read_text())
    assert audit['pass'] and audit['source']['source_git_commit'] == commit
functional = json.loads((base / 'sgi-official-wheel-tensor-control-success-archive/receipt.json').read_text())
assert functional['pass']
out.mkdir()
for name in ('runs', 'logs', 'receipts', 'sdk-libraries'):
    (out / name).mkdir()
for name in ('process_handoff.py', 'process_handoff.sbatch'):
    shutil.copyfile(base / name, out / name)
for p in (validation / 'sdk-libraries').iterdir():
    shutil.copyfile(p, out / 'sdk-libraries' / p.name)
prior = json.loads((validation / 'binding.json').read_text())
assert prior['source_git_commit'] == commit
binding = dict(
    harness_commit='dbc27f68673d2467b49a38aa177487db4973c4db', flashinfer_source_commit=commit,
    normal_wheel_sha256=prior['wheel_sha256'], source=prior['source'],
    source_ledger_sha256=prior['source_ledger_sha256'], vendor_git_pins=prior['vendor_git_pins'],
    geometry='Previously exposed BF16 ragged unsplit causal, Q[3,39,107,175,243,311,411] cached[22528,16512,11840,8256,2624,672,80]',
    producer_processes_per_gpu=1, fresh_consumer_processes_per_gpu=2,
    modes=['eager_run-1', 'graph_replay-1', 'graph_replay-16'],
    consumers_never_calibrate_or_tune=True, private_jit_root_per_process=True,
    actual_public_confidence_load_and_managed_v2_replay=True,
    eager_same_geometry_rebind=True, fixed_graph_same_pointer_input_updates=True,
    metadata_updates_or_full_serving_qualified=False, independent_performance_qualified=False,
    fresh_cases_consumed=0, all_started_results_retained=True,
    qualification_authority=False, full_http_qualified=False, default_promotion=False,
    serving_promotion=False, historical_token_divergence_resolved=False,
)
(out / 'binding.json').write_text(json.dumps(binding, indent=2) + '\n')
(out / 'validation.sha256').write_text(''.join(
    f'{sha(p)}  {p}\n' for p in sorted(out.rglob('*')) if p.is_file()
))
jobs = {}
for gpu in ('gpu_4090', 'gpu_5090'):
    jobs[gpu] = subprocess.check_output([
        'sbatch', '--parsable', '-p', gpu, '-o', str(out / 'logs/%j.out'),
        '-e', str(out / 'logs/%j.err'), str(out / 'process_handoff.sbatch'),
        str(out), prior['source'], commit,
    ], text=True).strip()
    (out / 'receipts/jobs.json').write_text(json.dumps(jobs, indent=2) + '\n')
print(json.dumps(dict(campaign=str(out), jobs=jobs)))
