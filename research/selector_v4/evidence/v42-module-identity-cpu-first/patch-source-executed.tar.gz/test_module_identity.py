# Copyright (c) 2026 by FlashInfer team.
# Licensed under the Apache License, Version 2.0.
from types import SimpleNamespace
from unittest.mock import Mock

import pytest

pytest.importorskip("torch")
from flashinfer.experimental.prefill_resource import _jit, _ops


@pytest.fixture
def loaded(monkeypatch):
    monkeypatch.setattr(_ops, "_module_bindings", {})
    spec = Mock(return_value=SimpleNamespace(name="unused-test-spec"))
    register = Mock(return_value=object())
    monkeypatch.setattr(_ops, "resource_spec", spec)
    monkeypatch.setattr(_ops, "_register_resource_module", register)
    return spec, register


def test_same_module_envelope_registers_once(loaded):
    spec, register = loaded
    a = _ops.resource_module(
        "dtype-template", source_id="source-A", compilation_identity="compiler-A"
    )
    b = _ops.resource_module(
        "dtype-template", source_id="source-A", compilation_identity="compiler-A"
    )
    assert a is b
    spec.assert_called_once_with("dtype-template", expected_source_id="source-A")
    assert register.call_count == 1


@pytest.mark.parametrize(
    "source,compiler", [("source-B", "compiler-A"), ("source-A", "compiler-B")]
)
def test_changed_source_or_compiler_cannot_borrow_old_module(loaded, source, compiler):
    spec, register = loaded
    original = _ops.resource_module(
        "dtype-template", source_id="source-A", compilation_identity="compiler-A"
    )
    with pytest.raises(RuntimeError, match="identity changed in this process"):
        _ops.resource_module(
            "dtype-template", source_id=source, compilation_identity=compiler
        )
    assert spec.call_count == register.call_count == 1
    assert (
        _ops.resource_module(
            "dtype-template", source_id="source-A", compilation_identity="compiler-A"
        )
        is original
    )


def test_failed_registration_does_not_publish_a_module_identity(loaded):
    spec, register = loaded
    register.side_effect = RuntimeError("load failed")
    with pytest.raises(RuntimeError, match="load failed"):
        _ops.resource_module(
            "dtype-template", source_id="source-A", compilation_identity="compiler-A"
        )
    assert not _ops._module_bindings
    register.side_effect = None
    result = _ops.resource_module(
        "dtype-template", source_id="source-A", compilation_identity="compiler-A"
    )
    assert result is register.return_value and spec.call_count == 2


def test_source_changed_before_first_spec_rejects_without_native_generation(
    monkeypatch,
):
    from flashinfer.jit.attention import modules

    generator = Mock(side_effect=AssertionError("No source generation is authorized"))
    monkeypatch.setattr(_jit, "source_contract", lambda *args: "new-source")
    monkeypatch.setattr(modules, "_gen_batch_prefill_primary_module", generator)
    with pytest.raises(ValueError, match="source changed after runner identity"):
        _jit.resource_spec("dtype-template", expected_source_id="old-source")
    generator.assert_not_called()
