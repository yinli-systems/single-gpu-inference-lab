"""Finite exact source gate: dual69/SASS before one exposed public setup diagnosis."""
from pathlib import Path
import hashlib,json,subprocess,time,datetime
b=Path('/ssd/scxi253');p=b/'sgi-module-bound-source-prequalification';p.mkdir();v=b/'sgi-official-wheel-validation-bab48695-20261001';e=b/'q7b-engines-20260925T1247Z/envs/sglang312/bin/python';sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
helpers=['archive_official_wheel_module_bound_success.py','archive_official_build_module_bound_proof.py','audit_main_sass.py','prepare_plan_setup_cost.py','plan_setup_cost.py','plan_setup_cost.sbatch']
s=dict(state='WAIT_NORMAL_BUILD_AND_DUAL69',source_commit='bab48695bbe72ba23c49bad69818b2975f3de6f7',helpers={n:sha(b/n) for n in helpers},fresh_cases_consumed=0,release48_consumed=0,stress12_consumed=0,default_promotion=False,serving_promotion=False,historical_token_divergence_resolved=False,qualification_authority=False)
def save():
 s['updated_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();f=p/'receipt.tmp';f.write_text(json.dumps(s,indent=2)+'\n');f.replace(p/'receipt.json')
def execute(args,name,timeout=1800):
 with (p/name).open('w') as f:subprocess.run(args,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=timeout)
save()
try:
 deadline=time.monotonic()+14400
 while not (v/'receipts/jobs.json').exists():
  if time.monotonic()>deadline:raise TimeoutError('Finite normal-source dispatch deadline')
  time.sleep(15)
 jobs=json.loads((v/'receipts/jobs.json').read_text());assert len(jobs)==2;s['jobs']=jobs;save()
 while True:
  done=[]
  for job in jobs.values():
   f=v/f'receipts/exit-{job}.txt'
   if f.exists():assert f.read_text().strip()=='0',str(f);done.append(job)
   else:
    status=subprocess.check_output(['sacct','-j',job,'--format=State','-n','-X'],text=True).strip();assert not any(k in status for k in ['FAILED','CANCELLED','TIMEOUT','NODE_FAIL','OUT_OF_MEMORY']),status
  if len(done)==2:break
  if time.monotonic()>deadline:raise TimeoutError('Finite dual69 deadline')
  time.sleep(15)
 for n,h in s['helpers'].items():assert sha(b/n)==h,n
 execute([str(e),str(b/'archive_official_wheel_module_bound_success.py')],'dual69-archive.log')
 execute([str(e),str(b/'archive_official_build_module_bound_proof.py')],'normal-build-proof.log')
 s['state']='AUDIT_EXACT_MODULE_BOUND_NATIVE_SASS';s['sass']={};save()
 for gpu,job in jobs.items():
  out=b/('sgi-official-wheel-module-bound-sass-'+gpu);execute([str(e),str(b/'audit_main_sass.py'),str(v),job,str(out)],'sass-'+gpu+'.log',2400)
  r=json.loads((out/'receipt.json').read_text());s['sass'][gpu]=dict(pass_=r['pass'],paired_kernels=r['paired_kernels'],receipt_sha256=sha(out/'receipt.json'));save();assert r['pass'],gpu
 s['state']='EXACT_MODULE_BOUND_DUAL69_AND_SASS_PASS';save()
 execute([str(e),str(b/'prepare_plan_setup_cost.py')],'exposed-public-setup-dispatch.log')
 root=next(b.glob('sgi-public-plan-setup-*-bab48695-20261001'));s.update(state='EXPOSED_PUBLIC_PLAN_SETUP_DISPATCHED',terminal=True,diagnostic_root=str(root),diagnostic_jobs=json.loads((root/'receipts/jobs.json').read_text()));save()
except BaseException as ex:
 s.update(state='MODULE_BOUND_SOURCE_GATE_HOLD',terminal=True,error=dict(type=type(ex).__name__,message=str(ex)));save();raise
print(json.dumps(s))
