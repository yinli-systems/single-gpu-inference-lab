"""Fixed exposed kernel/launch diagnosis, independent of performance gates."""

import hashlib
import json
import shutil
import subprocess
from pathlib import Path

b = Path('/ssd/scxi253')
p = b / 'sgi-serving-kernel-profile-00deb7e-75544a17-20261001'
v = b / 'sgi-official-wheel-validation-75544a17-20261001'
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
gate = json.loads((b / 'sgi-tensor-control-source-prequalification/receipt.json').read_text())
assert gate['state'] == 'EXACT_TENSOR_CONTROL_DUAL90_AND_SASS_PASS'
prior = json.loads((v / 'binding.json').read_text())
assert prior['source_git_commit'] == '75544a17ce0019ca877f50354d95451ee089f859'
p.mkdir()
for n in ('runs','logs','receipts','sdk-libraries'): (p/n).mkdir()
for n in ('serving_kernel_profile.py','serving_kernel_profile.sbatch','prepare_serving_kernel_profile.py'):shutil.copyfile(b/n,p/n)
for f in (v/'sdk-libraries').iterdir():shutil.copyfile(f,p/'sdk-libraries'/f.name)
binding = dict(harness_commit='00deb7ef5e5097e59407831f97bc09b361ebeb30',
    flashinfer_commit=prior['source_git_commit'], normal_wheel_sha256=prior['wheel_sha256'],
    source=prior['source'], source_ledger_sha256=prior['source_ledger_sha256'],
    vendor_git_pins=prior['vendor_git_pins'],
    scope='Previously exposed BF16 Qwen-style causal ragged suffix projection stride6144 and noncausal page1 cached prefix.',
    uncertified_raw_resource_diagnostic=True, native_after_resource_exact=True,
    fixed_blocks_per_l2_state=8, fixed_event_iterations_per_window=64,
    l2_states=['warm','cold'], all_started_observations_retained=True,
    preferred_cupti_python_unavailable_uses_documented_event_fallback=True,
    independent_torch_cupti_launch_trace=True, hardware_residency_counters_collected=False,
    fresh_cases_consumed=0, qualification_authority=False, full_http_qualified=False,
    default_promotion=False, serving_promotion=False, historical_token_divergence_resolved=False)
(p/'binding.json').write_text(json.dumps(binding,indent=2)+'\n')
(p/'validation.sha256').write_text(''.join(f'{sha(f)}  {f}\n' for f in sorted(p.rglob('*')) if f.is_file()))
jobs = {}
for gpu in ('gpu_4090','gpu_5090'):
    jobs[gpu] = subprocess.check_output(['sbatch','--parsable','-p',gpu,
        '-o',str(p/'logs/%j.out'),'-e',str(p/'logs/%j.err'),str(p/'serving_kernel_profile.sbatch'),
        str(p),prior['source']],text=True).strip()
    (p/'receipts/jobs.json').write_text(json.dumps(jobs,indent=2)+'\n')
print(json.dumps({'campaign':str(p),'jobs':jobs}))
