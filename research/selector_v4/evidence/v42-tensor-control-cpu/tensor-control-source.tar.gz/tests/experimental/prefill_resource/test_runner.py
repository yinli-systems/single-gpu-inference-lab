# Copyright (c) 2026 by FlashInfer team.
# Licensed under the Apache License, Version 2.0.
from types import SimpleNamespace
from unittest.mock import MagicMock, patch

import pytest

torch = pytest.importorskip("torch")
from flashinfer.autotuner import AutoTuner
from flashinfer.experimental.prefill_resource._policy import confidence_receipt
from flashinfer.experimental.prefill_resource._runner import (
    ResourceCapRunner,
    option_signature,
)
from flashinfer.prefill import BatchPrefillWithRaggedKVCacheWrapper


def make_runner(*, workspace=False):
    wrapper = object.__new__(BatchPrefillWithRaggedKVCacheWrapper)
    wrapper._backend = "fa2"
    wrapper._jit_module = None
    wrapper._pos_encoding_mode = "NONE"
    wrapper._use_fp16_qk_reduction = False
    wrapper._window_left = -1
    wrapper._logits_soft_cap = 0.0
    wrapper._kv_layout = "NHD"
    wrapper._plan_info = [7, 128, 0, 128, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
    wrapper._cached_module = SimpleNamespace()
    if workspace:
        wrapper._float_workspace_buffer = torch.zeros(32)
    wrapper.run = MagicMock(return_value="native")
    wrapper._qo_indptr_buf = torch.tensor([0, 128], dtype=torch.int32)
    wrapper._kv_indptr_buf = torch.tensor([0, 128], dtype=torch.int32)
    inputs = [
        torch.ones(128, 32, 128),
        torch.ones(128, 8, 128),
        torch.ones(128, 8, 128),
    ]
    runner = ResourceCapRunner(
        wrapper,
        inputs,
        qo_lengths=[128],
        kv_lengths=[128],
        execution_mode="eager_run",
        graph_replays=1,
    )
    runner._resource = MagicMock(return_value="resource")
    return runner, inputs


def certify(runner):
    runner.receipt = confidence_receipt(
        runner.identity, [[1.35, 1, 1, 1.35]] * 32, exact=True
    )


def test_uncalibrated_cached_cap_is_native():
    runner, inputs = make_runner()
    assert runner.forward(inputs, tactic=1) == "native"
    runner._resource.assert_not_called()


def test_unsupported_device_remains_native_with_valid_receipt():
    runner, inputs = make_runner()
    certify(runner)
    assert runner.forward(inputs, tactic=1) == "native"
    assert runner.get_valid_tactics(inputs, None) == [0]


def test_stale_managed_autotuner_cap_falls_back():
    runner, inputs = make_runner()
    with patch.object(AutoTuner.get(), "choose_one", return_value=(runner, 1)):
        assert runner.run(inputs) == "native"


def test_replanning_rejects_previously_certified_tactic():
    runner, inputs = make_runner()
    runner._eligible = True
    certify(runner)
    assert runner.forward(inputs, tactic=1) == "resource"
    runner.wrapper._plan_info = list(runner.wrapper._plan_info)
    assert runner.forward(inputs, tactic=1) == "native"


def test_metadata_mutation_rejects_cap():
    runner, inputs = make_runner()
    runner._eligible = True
    certify(runner)
    runner.wrapper._qo_indptr_buf[1] = 127
    assert runner.forward(inputs, tactic=1) == "native"


def test_workspace_scratch_writes_preserve_certified_plan():
    runner, inputs = make_runner(workspace=True)
    runner._eligible = True
    certify(runner)
    runner.wrapper._float_workspace_buffer.fill_(42)
    assert runner.forward(inputs, tactic=1) == "resource"
    runner.wrapper._float_workspace_buffer.resize_(16)
    assert runner.forward(inputs, tactic=1) == "native"


def test_returned_receipt_cannot_mutate_installed_certificate():
    runner, _ = make_runner()
    certify(runner)
    exposed = runner.receipt
    exposed["samples"][0][0] = 0.9
    assert runner.receipt["samples"][0][0] == 1.35


def test_atomic_receipt_roundtrip_and_corruption(tmp_path):
    runner, _ = make_runner()
    certify(runner)
    assert runner.save_receipt(tmp_path)
    assert runner.load_receipt(tmp_path)
    runner._receipt_path(tmp_path).write_text("broken")
    assert not runner.load_receipt(tmp_path)
    assert runner.receipt is None


def test_unknown_tactic_and_changed_options_are_native():
    runner, inputs = make_runner()
    runner._eligible = True
    certify(runner)
    assert runner.forward(inputs, tactic=999) == "native"
    assert runner.forward(inputs, tactic=1, return_lse=True) == "native"


def test_synthesized_input_values_do_not_change_managed_cache_key():
    runner, inputs = make_runner()
    key = runner.get_cache_key_extras(inputs)
    assert runner.get_cache_key_extras([x * 2 for x in inputs]) == key


def test_graph_capture_never_triggers_lazy_compilation():
    runner, inputs = make_runner()
    runner._eligible = True
    with patch.object(torch.cuda, "is_current_stream_capturing", return_value=True):
        assert not runner._prepare(inputs)
    assert runner._proxy is None


def test_unloadable_resource_module_falls_back():
    runner, inputs = make_runner()
    runner._eligible = True
    with (
        patch.object(torch.cuda, "is_current_stream_capturing", return_value=False),
        patch(
            "flashinfer.experimental.prefill_resource._ops.resource_module",
            side_effect=RuntimeError("unloadable"),
        ),
    ):
        assert not runner._prepare(inputs)
    assert runner._proxy is None
    assert not runner._eligible
    assert runner.forward(inputs, tactic=1) == "native"


@pytest.mark.parametrize(
    "causal,kv_length", [(False, 13), (True, 13), (False, 0), (True, 0)]
)
def test_prefix_only_noncausal_geometry_and_causal_length_guard(causal, kv_length):
    original, inputs = make_runner()
    wrapper = original.wrapper
    wrapper._causal = causal
    wrapper._kv_indptr_buf = torch.tensor([0, kv_length], dtype=torch.int32)
    inputs = [inputs[0], inputs[1][:kv_length], inputs[2][:kv_length]]
    kwargs = dict(
        qo_lengths=[128],
        kv_lengths=[kv_length],
        execution_mode="eager_run",
        graph_replays=1,
    )
    if causal or kv_length == 0:
        with pytest.raises(ValueError, match="Positive query/KV lengths"):
            ResourceCapRunner(wrapper, inputs, **kwargs)
    else:
        runner = ResourceCapRunner(wrapper, inputs, **kwargs)
        # CPU remains unsupported regardless of an accepted host geometry.
        assert not runner._eligible and runner.forward(inputs, tactic=1) == "native"
        assert runner.qo_lengths == (128,) and runner.kv_lengths == (13,)


def test_compiler_options_change_module_and_confidence_identities(monkeypatch):
    monkeypatch.delenv("NVCC_APPEND_FLAGS", raising=False)
    first, _ = make_runner()
    monkeypatch.setenv("NVCC_APPEND_FLAGS", "-DRESOURCE_IDENTITY_TEST=1")
    second, _ = make_runner()
    assert first.compilation_identity != second.compilation_identity
    assert first.identity != second.identity


def test_control_tensor_value_update_and_replacement_rejects_cached_cap():
    runner, inputs = make_runner()
    scale = torch.tensor(1.0)
    runner._run_kwargs = {"q_scale": scale}
    runner._run_options = option_signature(runner._run_kwargs)
    runner._eligible = True
    certify(runner)
    assert runner.forward(inputs, tactic=1) == "resource"
    scale.fill_(2.0)
    assert runner.forward(inputs, tactic=1) == "native"
    scale.fill_(1.0)
    assert runner.forward(inputs, tactic=1) == "native"
    runner._run_options = option_signature(runner._run_kwargs)
    assert runner.forward(inputs, tactic=1, q_scale=scale.clone()) == "native"


def test_output_tensor_scratch_updates_preserve_options():
    runner, inputs = make_runner()
    output = torch.zeros_like(inputs[0])
    lse = torch.zeros(128, 32)
    runner._run_kwargs = {"out": output, "lse": lse}
    runner._run_options = option_signature(runner._run_kwargs)
    runner._eligible = True
    certify(runner)
    output.fill_(42)
    lse.fill_(9)
    assert runner.forward(inputs, tactic=1) == "resource"
    output.resize_(1)
    assert runner.forward(inputs, tactic=1) == "native"


def test_untracked_control_tensor_rejects_without_cold_source_scan():
    runner, inputs = make_runner()
    with torch.inference_mode():
        runner._run_kwargs = {"q_scale": torch.tensor(1.0)}
    with patch(
        "flashinfer.experimental.prefill_resource._jit.source_contract",
        side_effect=AssertionError("Unsupported control must reject before cold scan"),
    ):
        assert not runner._static_support(inputs)
