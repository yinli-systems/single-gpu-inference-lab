"""Compact provenance archive; large source and unchanged wheel stay SHA-bound remotely."""
from pathlib import Path
import hashlib, json, tarfile

b = Path('/ssd/scxi253')
p = b / 'sgi-flashinfer-official-build-13ae45c2-20261001'
out = b / 'sgi-official-build-prefix-proof-archive'; out.mkdir()
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
r = json.loads((p / 'receipt.json').read_text())
assert r['build_pass'] and r['normal_upstream_hook']
assert r['all_non_generated_wheel_package_bytes_match_prebuild_source_ledger']
for name, expected in ((r['wheel'],r['wheel_sha256']), (r['source_archive'],r['source_archive_sha256'])):
    assert sha(Path(name)) == expected
files = {}
def add(f, name):
    assert f.is_file(), f
    files[name] = f
for n in ('receipt.json','build.log','input-git-blobs.json','input-source-files.json',
          'wheel-package-files.json','wheel-package-source-map.json'):
    add(p / n, 'build/' + n)
for n in ('pyproject.toml','build_backend.py','build_utils.py','version.txt','requirements.txt',
          'flashinfer/_build_meta.py'):
    add(p / 'source' / n, 'source-build-input/' + n)
for n in ('sgi-d7683dd-official-sparse-source-receipt.json','wheel-vendor-git-proof-sparse.json',
          'sgi-vendor-target-ledger.json.gz','sgi-required-main-corrections.json.gz',
          'sgi-required-vendor-corrections.json.gz','sgi-cccl-pinned-metadata.pack',
          'sgi-cutlass-pinned-metadata.pack','sgi-spdlog-pinned-metadata.pack',
          'sgi-prefix-short-update.bundle','sgi-d7683dd-update.bundle',
          'sgi-official-build-prefix-controller.log',
          'build_official_wheel_prefix.py','verify_official_wheel_prefix.py',
          'finalize_verified_sparse_source.py','archive_official_build_prefix_proof.py'):
    add(b / n, 'source-preparation/' + n)
for pattern in ('sgi-*source*.log', 'sgi-sparse-source-*/completion.log'):
    for f in b.glob(pattern):
        if f.is_file(): add(f,'source-preparation/logs/' + str(f.relative_to(b)).replace('/','__'))
ledger = {n:sha(f) for n,f in sorted(files.items())}
a = out / 'raw-official-build-proof.tar.gz'
with tarfile.open(a,'w:gz',dereference=True) as t:
    for n,f in sorted(files.items()): t.add(f,arcname=n,recursive=False)
with tarfile.open(a) as t:
    for n,h in ledger.items(): assert hashlib.sha256(t.extractfile(n).read()).hexdigest() == h
receipt = dict(build_pass=True, binding=r, files=ledger,
    archive_sha256=sha(a),archive_bytes=a.stat().st_size,
    large_artifacts_retained_remotely=[dict(path=r['wheel'],sha256=r['wheel_sha256'],bytes=r['wheel_bytes']),
        dict(path=r['source_archive'],sha256=r['source_archive_sha256'],bytes=r['source_archive_bytes'])],
    wheel_rebuilt_after_checker_failure=False,wheel_modified=False,
    normal_package_metadata=True,source_and_compiler_headers_git_authenticated=True,
    omitted_paths_non_build_only=True,shared_environment_changed=False,
    gpu_qualified=False,default_promotion=False,serving_promotion=False,
    historical_token_divergence_resolved=False,fresh_cases_consumed=0)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('build_pass','archive_bytes','archive_sha256')}))
