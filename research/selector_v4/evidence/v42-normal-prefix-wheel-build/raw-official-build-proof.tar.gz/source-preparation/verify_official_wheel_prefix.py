"""Verify an unchanged normal wheel using upstream setuptools package-dir mappings."""
from pathlib import Path
import hashlib, json, subprocess, tomllib, zipfile

b = Path('/ssd/scxi253')
p = b / 'sgi-flashinfer-official-build-13ae45c2-20261001'
s = p / 'source'
assert not (p / 'receipt.json').exists()
commit = '13ae45c2283f54fc2cf2461b7ed7a0d4c5e84305'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip() == commit
sha = lambda f: hashlib.sha256(f.read_bytes()).hexdigest()
r = json.loads((b / 'sgi-d7683dd-official-sparse-source-receipt.json').read_text())
cfg = tomllib.loads((s / 'pyproject.toml').read_text())
mapping = cfg['tool']['setuptools']['package-dir']
assert mapping == {'flashinfer.data':'.', 'flashinfer.data.cutlass':'3rdparty/cutlass',
                   'flashinfer.data.spdlog':'3rdparty/spdlog', 'flashinfer.data.cccl':'3rdparty/cccl'}
prefixes = sorted(((k.replace('.','/') + '/', v) for k,v in mapping.items()), key=lambda x:-len(x[0]))
wheels = list((p / 'wheels').glob('*.whl')); assert len(wheels) == 1
w = wheels[0]; ledger = {}; translated = {}
inputs = json.loads((p / 'input-source-files.json').read_text())
with zipfile.ZipFile(w) as z:
    metadata = z.read('flashinfer/_build_meta.py').decode()
    assert '__version__ = "0.7.1"' in metadata and commit in metadata
    for name in z.namelist():
        if not name.startswith('flashinfer/') or name.endswith('/'): continue
        relative = name
        for prefix, target in prefixes:
            if name.startswith(prefix):
                relative = str(Path(target) / name[len(prefix):]); break
        f = s / relative
        assert f.is_file(), (name, relative)
        digest = hashlib.sha256(z.read(name)).hexdigest()
        assert digest == sha(f), name
        # Compiler and package source were Git/input-ledger authenticated before building.
        if name != 'flashinfer/_build_meta.py': assert inputs[relative] == digest, name
        ledger[name] = digest
        if relative != name: translated[name] = relative
    assert hashlib.sha256(z.read('flashinfer/prefill.py')[:344213]).hexdigest() == '059a9dc01d652de9b7b70bbf6efecd736f6086e36f11941cd7eb972b5bbea006'
    distribution = z.read(next(n for n in z.namelist() if n.endswith('.dist-info/METADATA'))).decode()
    assert 'Version: 0.7.1\n' in distribution
(p / 'wheel-package-files.json').write_text(json.dumps(ledger,indent=2)+'\n')
(p / 'wheel-package-source-map.json').write_text(json.dumps(translated,indent=2)+'\n')
a = p / 'input-source.tar.gz'
receipt = dict(
    build_pass=True, source_git_commit=commit, native_base='85744da1a397c0c4bea1a83b8345281750eb61a9',
    baseline_sparse_source_receipt_sha256=sha(b/'sgi-d7683dd-official-sparse-source-receipt.json'),
    source_archive=str(a),source_archive_sha256=sha(a),source_archive_bytes=a.stat().st_size,
    vendor_git_pins={n:x['git_commit'] for n,x in r['vendor_git_blob_proof'].items()},
    vendor_git_blob_proof=r['vendor_git_blob_proof'],
    input_source_ledger_sha256=sha(p/'input-source-files.json'),
    input_git_blobs_sha256=sha(p/'input-git-blobs.json'),
    tracked_present_blobs_verified=len(json.loads((p/'input-git-blobs.json').read_text())),
    incremental_bundle_sha256=sha(b/'sgi-prefix-short-update.bundle'),
    wheel=str(w),wheel_sha256=sha(w),wheel_bytes=w.stat().st_size,metadata=metadata,
    package_files_verified=len(ledger),upstream_package_dir_mapping=mapping,
    wheel_package_file_ledger_sha256=sha(p/'wheel-package-files.json'),
    wheel_package_source_map_sha256=sha(p/'wheel-package-source-map.json'),
    all_wheel_package_bytes_match_normal_build_source=True,
    all_non_generated_wheel_package_bytes_match_prebuild_source_ledger=True,
    build_log_sha256=sha(p/'build.log'),normal_upstream_hook=True,
    verification_helper_sha256=sha(Path(__file__)),
    optional_nvep_build_disabled=True,hook_package_installs_disabled=True,
    shared_python_environment_changed=False,version_manually_overridden=False,
    all_runtime_vendor_header_paths_present=True,sparse_non_build_paths_omitted=True,
    fresh_cases_consumed=0,gpu_requalification_pending=True,tests_expected=61,full_serving_qualified=False,
)
(p/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('build_pass','wheel_sha256','wheel_bytes','package_files_verified')}))
