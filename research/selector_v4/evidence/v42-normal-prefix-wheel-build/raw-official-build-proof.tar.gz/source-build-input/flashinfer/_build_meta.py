"""Build metadata for flashinfer package."""
__version__ = "0.7.1"
__git_commit__ = "13ae45c2283f54fc2cf2461b7ed7a0d4c5e84305"
