"""Archive complete native-only 36-layer metadata boundary diagnostic."""
from pathlib import Path
import hashlib,json,os,subprocess,tarfile,xml.etree.ElementTree as ET
b=Path('/ssd/scxi253');p=b/'sgi-http-metadata-boundary-8739e37-75544a17-20261001'
out=b/'sgi-http-metadata-boundary-8739e37-complete-archive'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
job=json.loads((p/'receipts/jobs.json').read_text())['gpu_4090']
status=subprocess.check_output(['sacct','-j',job,'--format=JobID,State,ExitCode,Elapsed','-n','-X'],text=True)
assert 'COMPLETED' in status and '0:0' in status and (p/f'receipts/exit-{job}.txt').read_text().strip()=='0'
run=p/f'runs/full-http-{job}'
complete=json.loads((run/'complete.json').read_text());boundary=json.loads((run/'metadata-boundary-summary.json').read_text())
assert complete['complete'] and complete['pass_'] and not complete['resource_tactic_selected'] and not complete['timing_valid']
assert sum(x['samples']*x['completion_tokens'] for x in complete['requests'])==112
assert boundary['pass_'] and not boundary['resource_enabled'] and boundary['last']['adapter_depth_after_model']==0
assert boundary['last']['actual_prefill_updater_calls_inside_notified_boundary']>0
assert boundary['last']['adapter_counters']['graph_updates']>0
for record in (complete,boundary):
 for n,h in record.get('files',record.get('geometry_files',{})).items():assert sha(run/n)==h,n
suite=ET.parse(p/'receipts/cpu-tests.xml').getroot().find('testsuite');assert tuple(suite.attrib[n] for n in ('tests','failures','errors','skipped'))==('32','0','0','0')
files={};sources={}
for parent,dirs,names in os.walk(p):
 dirs[:]=[d for d in dirs if d not in ('cache','sdk-libraries','__pycache__','.pytest_cache') and not d.startswith('xdg-')]
 for n in names:
  f=Path(parent)/n;name=str(f.relative_to(p));files[name]=sha(f);sources[name]=f
helper=Path(__file__);files[helper.name]=sha(helper);sources[helper.name]=helper
out.mkdir();a=out/'raw-native-http-boundaries.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for n in sorted(files):t.add(sources[n],arcname=n,recursive=False)
with tarfile.open(a) as t:
 assert set(t.getnames())==set(files)
 for n,h in files.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h,n
receipt=dict(pass_native_http_metadata_boundary=True,binding=json.loads((p/'binding.json').read_text()),sacct=status,job=job,cpu_tests_passed=32,http=complete,boundary=boundary,files=files,archive_sha256=sha(a),archive_bytes=a.stat().st_size,resource_tactic_selected=False,full_http_resource_qualified=False,timing_valid=False,qualification_authority=False,fresh_cases_consumed=0,default_promotion=False,serving_promotion=False,historical_token_divergence_resolved=False)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('pass_native_http_metadata_boundary','archive_sha256','archive_bytes')}))
