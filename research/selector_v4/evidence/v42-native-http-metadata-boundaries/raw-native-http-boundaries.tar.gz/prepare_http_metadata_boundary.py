"""Native-only full-model notification witness on exact normal packages."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile,xml.etree.ElementTree as ET
b=Path('/ssd/scxi253');v=b/'sgi-official-wheel-validation-75544a17-20261001'
h=b/'sgi-http-ownership-current-main-3825c5a-post1';s=v/'wheel-overlay'
spec=json.loads((b/'metadata-boundaries-source.json').read_text());sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
a=b/'metadata-boundaries-source.tar.gz';assert sha(a)==spec['archive_sha256']
gate=json.loads((b/'sgi-tensor-control-source-prequalification/receipt.json').read_text());assert gate['state']=='EXACT_TENSOR_CONTROL_DUAL90_AND_SASS_PASS'
p=b/f"sgi-http-metadata-boundary-{spec['harness_commit'][:7]}-75544a17-20261001";p.mkdir()
with tarfile.open(a) as t:
 assert set(t.getnames())==set(spec['files'])
 for n,digest in spec['files'].items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==digest
 t.extractall(p,filter='data')
for name in ('logs','receipts','runs','sdk-libraries'):(p/name).mkdir()
for name in ('http_metadata_boundary_probe.py','http_metadata_boundary.sbatch','prepare_http_metadata_boundary.py'):shutil.copyfile(b/name,p/name)
for f in (v/'sdk-libraries').iterdir():shutil.copyfile(f,p/'sdk-libraries'/f.name)
ledger=[]
for line in (h/'source.sha256').read_text().splitlines():
 digest,name=line.split(None,1);name=name.strip()
 if name.startswith('candidate/'):
  f=h/name;assert sha(f)==digest,name;ledger.append(f'{digest}  {f}\n')
assert len(ledger)>100
(p/'sglang-source.sha256').write_text(''.join(ledger))
backend=h/'candidate/python/sglang/srt/layers/attention/flashinfer_backend.py'
w=json.loads((v/'binding.json').read_text())
env=dict(os.environ,PYTHONPATH=str(p)+':'+str(s)+':'+str(s/'test-support'),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',CUDA_VISIBLE_DEVICES='')
with (p/'receipts/cpu-tests.log').open('w') as log:
 rc=subprocess.run([str(b/'q7b-engines-20260925T1247Z/envs/sglang312/bin/python'),'-m','pytest','-q','research/selector_v4/serving/test_metadata_adapter.py','research/selector_v4/serving/test_epoch_registry.py','--confcutdir=research/selector_v4/serving','--junitxml='+str(p/'receipts/cpu-tests.xml')],cwd=p,env=env,stdout=log,stderr=subprocess.STDOUT).returncode
assert rc==0
suite=ET.parse(p/'receipts/cpu-tests.xml').getroot().find('testsuite');assert tuple(suite.attrib[n] for n in ('tests','failures','errors','skipped'))==('32','0','0','0')
binding=dict(sglang_commit='3825c5a4b5e8a1a73ae62f0c0ba6eb35beb1a2ca',sglang_source=str(h/'candidate'),sglang_backend_sha256=sha(backend),sglang_source_ledger_sha256=sha(p/'sglang-source.sha256'),flashinfer_commit=w['source_git_commit'],normal_wheel_sha256=w['wheel_sha256'],flashinfer_overlay=str(s),flashinfer_source_ledger_sha256=sha(s/'source.sha256'),vendor_git_pins=w['vendor_git_pins'],observer_harness_commit=spec['harness_commit'],observer_sha256=sha(p/'research/selector_v4/serving/metadata_boundary_server.py'),source_files=spec['files'],cpu_tests_passed=32,full_model='Qwen3-4B-Instruct-2507',layers=36,resource_tactic_selected=False,registered_resource_geometries=0,timing_valid=False,fresh_kernel_cases_consumed=0,full_http_resource_qualified=False,historical_token_divergence_resolved=False,default_promotion=False,serving_promotion=False)
(p/'binding.json').write_text(json.dumps(binding,indent=2)+'\n')
(p/'validation.sha256').write_text(''.join(f'{sha(f)}  {f}\n' for f in sorted(p.rglob('*')) if f.is_file()))
job=subprocess.check_output(['sbatch','--parsable','-p','gpu_4090','-o',str(p/'logs/%j.out'),'-e',str(p/'logs/%j.err'),str(p/'http_metadata_boundary.sbatch'),str(p),str(s)],text=True).strip()
(p/'receipts/jobs.json').write_text(json.dumps({'gpu_4090':job},indent=2)+'\n')
print(json.dumps({'campaign':str(p),'job':job}))
