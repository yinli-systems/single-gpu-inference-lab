"""Build metadata for flashinfer package."""
__version__ = "0.7.1"
__git_commit__ = "85744da1a397c0c4bea1a83b8345281750eb61a9"
