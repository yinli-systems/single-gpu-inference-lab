"""Normal upstream wheel build for the independent pinned pristine reference."""
from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile,zipfile,sys
commit=sys.argv[1];assert len(commit)==40 and all(c in "0123456789abcdef" for c in commit)
b=Path('/ssd/scxi253');p=b/('sgi-flashinfer-official-build-'+commit[:8]+'-20261001');p.mkdir();s=p/'source';baseline=b/'sgi-d7683dd-official-sparse-source';base_receipt=b/'sgi-d7683dd-official-sparse-source-receipt.json';r=json.loads(base_receipt.read_text());assert r['main_git_blob_proof']['required_paths_complete'];assert all(x['required_paths_complete'] for x in r['vendor_git_blob_proof'].values())
subprocess.run(['cp','-a','--reflink=auto',str(baseline),str(s)],check=True)

subprocess.run(['git','fetch',str(b/'sgi-tensor-control-update.bundle'),'codex/flashinfer-native-resource-v42'],cwd=s,check=True)
subprocess.run(['git','checkout','--detach',commit],cwd=s,check=True)
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()==commit
proof={}
for row in subprocess.check_output(['git','ls-files','--stage','-z'],cwd=s).split(b'\0'):
 if not row:continue
 meta,path=row.split(b'\t',1);mode,blob,stage=meta.split();f=s/os.fsdecode(path)
 if mode==b'160000':continue
 if not f.exists() and not f.is_symlink():continue
 data=os.readlink(f).encode() if mode==b'120000' else f.read_bytes();assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest().encode()==blob,str(f);proof[os.fsdecode(path)]=blob.decode()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
(p/'input-git-blobs.json').write_text(json.dumps(proof,indent=2)+'\n')
ledger={str(f.relative_to(s)):sha(f) for f in sorted(s.rglob('*')) if f.is_file() and '.git' not in f.relative_to(s).parts};(p/'input-source-files.json').write_text(json.dumps(ledger,indent=2)+'\n')
a=p/'input-source.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for f in sorted(s.iterdir()):t.add(f,arcname=f.name)
(p/'wheels').mkdir();e=b/'q7b-engines-20260925T1247Z/envs/sglang312/bin/python';env=os.environ.copy();env.update(BUILD_NVEP='0',FLASHINFER_BUILD_NO_PIP='1',PYTHONNOUSERSITE='1');env.pop('PYTHONPATH',None)
with (p/'build.log').open('w') as log:subprocess.run([str(e),'-c','import build_backend; print(build_backend.build_wheel("'+str(p/'wheels')+'"))'],cwd=s,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
subprocess.run([str(e),str(b/"verify_official_wheel_pristine.py"),commit],check=True)
