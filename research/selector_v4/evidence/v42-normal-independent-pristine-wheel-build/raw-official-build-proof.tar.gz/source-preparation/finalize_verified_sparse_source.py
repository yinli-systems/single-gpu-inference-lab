"""Complete real sparse checkouts using only cache blobs matching the Git tree."""
from pathlib import Path
import datetime,gzip,hashlib,json,os,signal,subprocess,tarfile
b=Path('/ssd/scxi253');s=b/'sgi-d7683dd-official-sparse-source';assert s.is_dir()
rdir=b/'sgi-sparse-source-finalization';rdir.mkdir();log=rdir/'completion.log';actions=[]
lock=s/'.git/index.lock'
if lock.exists():lock.rename(rdir/'abandoned-index.lock')
def run(cmd,cwd,input=None):
 actions.append({'command':cmd,'cwd':str(cwd)})
 with log.open('a') as f:subprocess.run(cmd,cwd=cwd,input=input,text=True,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=1200)
def seed(root,cache):
 paths=[];expected=[];total=0
 for row in subprocess.check_output(['git','ls-tree','-r','-z','HEAD'],cwd=root).split(b'\0'):
  if not row:continue
  meta,path=row.split(b'\t',1);mode,kind,blob=meta.split()
  if kind!=b'blob' or mode==b'120000':continue
  f=cache/os.fsdecode(path)
  if not f.is_file():continue
  data=f.read_bytes();h=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest().encode()
  if h!=blob:continue
  paths.append(str(f));expected.append(blob.decode());total+=len(data)
 result=subprocess.run(['git','hash-object','-w','--no-filters','--stdin-paths'],cwd=root,input='\n'.join(paths)+'\n',text=True,capture_output=True,check=True)
 assert result.stdout.splitlines()==expected
 return {'matching_files_seeded':len(paths),'matching_bytes_seeded':total,'cache':str(cache),'only_exact_git_blob_matches_used':True}
# Assign the actual branch reference without checking out missing blobs yet.
run(['git','symbolic-ref','HEAD','refs/heads/codex/flashinfer-native-resource-v42'],s)
mainseed=seed(s,b/'sgi-flashinfer-main-resource-current-d7683dd-source')
with tarfile.open(b/'sgi-required-main-corrections.tar.gz') as t:t.extractall(rdir/'main-corrections',filter='data')
maincorrection=seed(s,rdir/'main-corrections')
selection=json.loads(gzip.decompress((b/'sgi-required-main-corrections.json.gz').read_bytes()))
patterns=['/'+name for name in selection['root_files']]+['/flashinfer/','/include/','/csrc/','/tests/experimental/prefill_resource/','/examples/experimental/prefill_resource.py']
run(['git','sparse-checkout','set','--no-cone','--stdin'],s,'\n'.join(patterns)+'\n')
run(['git','checkout','-f','codex/flashinfer-native-resource-v42'],s)
# The target runtime headers are authenticated against the vendor Git trees.
with tarfile.open(b/'sgi-required-vendor-corrections.tar.gz') as t:t.extractall(rdir/'vendor-corrections',filter='data')
corrections=json.loads(gzip.decompress((b/'sgi-required-vendor-corrections.json.gz').read_bytes()))
old=b/'q7b-engines-20260925T1247Z/envs/sglang312/lib/python3.12/site-packages/flashinfer/data'
vendors={'cccl':('https://github.com/NVIDIA/cccl.git',['libcudacxx/include','cub/cub','thrust/thrust']), 'cutlass':('https://github.com/NVIDIA/cutlass.git',['include','tools/util/include']), 'spdlog':('https://github.com/gabime/spdlog.git',['include'])};proof={};seedproof={}
(s/'3rdparty').mkdir(exist_ok=True)
for name,(url,paths) in vendors.items():
 v=s/'3rdparty'/name;v.mkdir(exist_ok=True);pin=subprocess.check_output(['git','ls-tree','HEAD','3rdparty/'+name],cwd=s,text=True).split()[2];assert pin==corrections[name]['commit']
 if not (v/'.git').exists():run(['git','init'],v)
 with (b/('sgi-'+name+'-pinned-metadata.pack')).open('rb') as pack,log.open('a') as output:
  subprocess.run(['git','index-pack','--stdin'],cwd=v,stdin=pack,stdout=output,stderr=subprocess.STDOUT,check=True,timeout=60)
 run(['git','symbolic-ref','HEAD','refs/heads/verified-pin'],v);run(['git','update-ref','refs/heads/verified-pin',pin],v)
 seedproof[name]={'existing_environment':seed(v,old/name),'verified_corrections':seed(v,rdir/'vendor-corrections'/name)}
 rootfiles=[]
 for entry in subprocess.check_output(['git','ls-tree','-z','HEAD'],cwd=v).split(b'\0'):
  if not entry:continue
  meta,path=entry.split(b'\t',1)
  if meta.split()[1]==b'blob':rootfiles.append(path.decode())
 patterns=['/'+p for p in rootfiles]+['/'+p+'/' for p in paths]
 run(['git','sparse-checkout','set','--no-cone','--stdin'],v,'\n'.join(patterns)+'\n');run(['git','checkout','--detach',pin],v)
 proof[name]={'git_commit':pin,'required_paths':paths}
# Verify every present tracked file against genuine index blobs, and require all
# declared compile-time paths. Sparse omissions contain no benchmark code.
def verify(root,paths):
 count=omitted=0
 for row in subprocess.check_output(['git','ls-files','--stage','-z'],cwd=root).split(b'\0'):
  if not row:continue
  meta,path=row.split(b'\t',1);mode,blob,stage=meta.split();name=os.fsdecode(path);f=root/name
  if mode==b'160000':continue
  required='/' not in name or any(name==p or name.startswith(p+'/') for p in paths)
  if not f.exists() and not f.is_symlink():assert not required,name;omitted+=1;continue
  data=os.readlink(f).encode() if mode==b'120000' else f.read_bytes()
  assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest().encode()==blob,str(f);count+=1
 return {'tracked_git_blobs_verified':count,'omitted_non_build_files':omitted,'all_present_tracked_git_blobs_match':True,'required_paths':paths,'required_paths_complete':True,'working_tree_clean':not bool(subprocess.check_output(['git','status','--porcelain'],cwd=root))}
mainpaths=['flashinfer','include','csrc','tests/experimental/prefill_resource','examples/experimental/prefill_resource.py'];mainproof=verify(s,mainpaths)
for name,r in proof.items():r.update(verify(s/'3rdparty'/name,r['required_paths']))
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=s,text=True).strip()=='d7683dd8e86af2f37e8d25162c45b01f80824378'
(b/'wheel-vendor-git-proof-sparse.json').write_text(json.dumps(proof,indent=2)+'\n')
a=b/'sgi-d7683dd-official-sparse-source.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for f in sorted(s.iterdir()):t.add(f,arcname=f.name)
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
r={'source_commit':'d7683dd8e86af2f37e8d25162c45b01f80824378','source_archive_sha256':sha(a),'source_archive_bytes':a.stat().st_size,'main_git_blob_proof':mainproof,'vendor_git_blob_proof':proof,'cache_seed_proof':{'main':mainseed,'main_corrections':maincorrection,'vendors':seedproof},'commands':actions,'recovery_log_sha256':sha(log),'normal_git_checkouts':True,'source_code_patched':False,'scope':'Complete package Python/native include/csrc and declared runtime vendor headers in genuine sparse checkouts. Non-build docs, examples, and vendor tests omitted. All present tracked bytes match Git blobs.','shared_python_environment_changed':False,'fresh_cases_consumed':0}
(b/'sgi-d7683dd-official-sparse-source-receipt.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
