"""Build metadata for flashinfer package."""
__version__ = "0.7.1"
__git_commit__ = "bab48695bbe72ba23c49bad69818b2975f3de6f7"
