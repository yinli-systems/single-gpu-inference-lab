# Copyright (c) 2026 by FlashInfer team.
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

"""JIT-only resource module; never writes native headers, sources or libraries."""

import dataclasses
import hashlib
import json
import os
import re
import shutil
from pathlib import Path

from filelock import FileLock

# This transform is intentionally version-bound. An unreviewed upstream change
# disables the experimental tactic rather than changing the stable backend.
SOURCE_HASHES = {
    "include/flashinfer/attention/prefill.cuh": "ad8be30492fb04131edc25b539ae77e911177af8647c7e2007cf172a4a69d029",
    "include/flashinfer/attention/scheduler.cuh": "b1fb27078084262158ed070e220ad317467306d1f0b32e0d9624bf85e6ef97ce",
    "csrc/batch_prefill.cu": "02264092de3836b9e75cb76533d820b3a8998417f83001216b368f394b250838",
    "csrc/batch_prefill_jit_binding.cu": "dad0d81c55b92f71a634cb8240dcb0d150aa6ffd391ef3ef5d87b6207eeca4fc",
    "csrc/batch_prefill_paged.cuh": "ae4a5efa8082311b931cc38819684118e0e29af76058abd13bc6038e637f6cb6",
    "csrc/batch_prefill_customize_config.jinja": "c8e1a08fc88fcac547cdbb343734b139febdd55cc94306bbf5268f94c82fefbf",
    "csrc/batch_prefill_paged_kernel_inst.jinja": "1e41a0ea9795847272674c1058a9d72f220facf296037cbf1f95ce6b77225a63",
    "csrc/batch_prefill_ragged_kernel_inst.jinja": "4e177455f914c3665cf38728883d74c076f368c1bea3736c0033675de342f687",
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


def resource_uri(source_id, transform_id, native_name):
    identity = json.dumps(
        {"source": source_id, "transform": transform_id, "native": native_name},
        sort_keys=True,
    ).encode()
    # Ninja prefixes object filenames with this URI. Hash the full identity so
    # a long native URI cannot exceed the filesystem's per-component limit.
    return "experimental_resource_" + digest(identity)


def transform_header(source):
    for layout in ("Ragged", "Paged"):
        prefix = f"BatchPrefillWith{layout}KVCache"
        source = re.sub(r"\b" + prefix + r"Kernel\b", prefix + "ResourceKernel", source)
        source = re.sub(
            r"\b" + prefix + r"Dispatched\b", prefix + "ResourceDispatched", source
        )
        line = (
            f"          auto kernel = {prefix}ResourceKernel<KTraits, Params>;"
            if layout == "Ragged"
            else f"          auto kernel = {prefix}ResourceKernel<SAME_KV_STRIDES, KTraits, Params>;"
        )
        if source.count(line) != 1:
            raise ValueError(f"Unrecognized {layout} resource dispatcher")
        guard = """
          const bool resource_eligible = HEAD_DIM_QK == 128 && HEAD_DIM_VO == 128 &&
              CTA_TILE_Q == 128 && sizeof(DTypeQ) == 2 && sizeof(DTypeKV) == 2 &&
              AttentionVariant::use_softmax && tmp_v == nullptr && smem_size == 49152 &&
              max_smem_per_sm >= 102400 && max_smem_per_block_optin >= 65536;
          if (!resource_eligible) return cudaErrorInvalidValue;
          smem_size = 65536;"""
        source = source.replace(line, line + guard)
    return source


def transform_source(source):
    for layout in ("Ragged", "Paged"):
        prefix = f"BatchPrefillWith{layout}KVCache"
        for suffix in ("Dispatched", "Run"):
            source = re.sub(
                r"\b" + prefix + suffix + r"\b", prefix + "Resource" + suffix, source
            )
    for suffix in ("Plan", "WorkspaceSize"):
        source = re.sub(
            r"\bBatchPrefillWithKVCache" + suffix + r"\b",
            "BatchPrefillResource" + suffix,
            source,
        )
    return source


def dependency_manifest(directories):
    """Fingerprint compiler include trees, including extensionless C++ headers."""
    result = {}
    for directory in sorted({Path(d).resolve() for d in directories}):
        if not directory.is_dir():
            raise ValueError(f"Missing compiler dependency include tree: {directory}")
        files = {}
        visited = set()
        for current, folders, names in os.walk(directory, followlinks=True):
            resolved = Path(current).resolve()
            if resolved in visited:
                raise ValueError(
                    f"Cyclic compiler dependency include tree: {directory}"
                )
            visited.add(resolved)
            for name in sorted(names):
                path = Path(current) / name
                if not path.is_file():
                    raise ValueError(f"Unreadable compiler dependency: {path}")
                files[str(path.relative_to(directory))] = digest(path.read_bytes())
        if not files:
            raise ValueError(f"Empty compiler dependency include tree: {directory}")
        result[str(directory)] = files
    return result


def packaged_dependency_dirs(env):
    return (*env.CCCL_INCLUDE_DIRS, *env.CUTLASS_INCLUDE_DIRS, env.SPDLOG_INCLUDE_DIR)


def source_contract(include_dir, csrc_dir, dependency_dirs=()):
    values = {}
    for name, expected in SOURCE_HASHES.items():
        base, relative = name.split("/", 1)
        path = (include_dir if base == "include" else csrc_dir) / relative
        actual = digest(path.read_bytes())
        if actual != expected:
            raise ValueError(f"Unreviewed FA2 source: {name}")
        values[name] = actual
    # Bind all copied dependencies as well as the reviewed transform anchors.
    # An unrelated header change may cause a conservative cache miss.
    for label, directory in (("include", include_dir), ("csrc", csrc_dir)):
        for path in sorted(directory.rglob("*")):
            if path.is_file() and path.suffix in (".h", ".cuh", ".inc", ".jinja"):
                values[label + "/" + str(path.relative_to(directory))] = digest(
                    path.read_bytes()
                )
    values["compiler_dependency_headers"] = dependency_manifest(dependency_dirs)
    return digest(json.dumps(values, sort_keys=True).encode())


def resource_spec(*module_args, expected_source_id):
    from flashinfer.jit import env
    from flashinfer.jit.attention.modules import _gen_batch_prefill_primary_module
    from flashinfer.jit.core import jit_spec_registry
    from flashinfer.jit.utils import write_if_different

    source_id = source_contract(
        env.FLASHINFER_INCLUDE_DIR,
        env.FLASHINFER_CSRC_DIR,
        packaged_dependency_dirs(env),
    )
    if source_id != expected_source_id:
        raise ValueError(
            "Resource source changed after runner identity was established"
        )
    # Use the ordinary generator only for source construction. Its native spec
    # is never built, patched or registered as an experimental AOT operation.
    native = _gen_batch_prefill_primary_module("fa2", *module_args)
    transform_id = digest(Path(__file__).read_bytes())
    name = resource_uri(source_id, transform_id, native.name)
    directory = env.FLASHINFER_GEN_SRC_DIR / name
    directory.mkdir(parents=True, exist_ok=True)
    private_include = directory / "include"
    with FileLock(str(directory / "sources.lock")):
        # Relative includes in prefill.cuh require the original directory layout.
        # Copy the include tree under the private URI, keeping native files intact.
        shutil.copytree(env.FLASHINFER_INCLUDE_DIR, private_include, dirs_exist_ok=True)
        header = private_include / "flashinfer/attention/prefill.cuh"
        write_if_different(header, transform_header(header.read_text()))
        for original in native.sources:
            write_if_different(
                directory / original.name, transform_source(original.read_text())
            )
        for original in native.sources[0].parent.iterdir():
            if original.suffix in (".inc", ".cuh"):
                write_if_different(
                    directory / original.name, transform_source(original.read_text())
                )
        spec = dataclasses.replace(
            native,
            name=name,
            sources=[directory / p.name for p in native.sources],
            extra_include_dirs=[private_include, *(native.extra_include_dirs or [])],
        )
    jit_spec_registry.register(spec)
    return spec
