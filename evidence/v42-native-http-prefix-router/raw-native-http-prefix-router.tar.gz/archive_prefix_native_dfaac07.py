"""Archive complete native-only 36-layer metadata boundary diagnostic."""
from pathlib import Path
import hashlib,json,os,subprocess,tarfile,xml.etree.ElementTree as ET
b=Path('/ssd/scxi253');p=b/'sgi-http-prefix-native-dfaac07-75544a17-20261001'
out=b/'sgi-http-prefix-native-dfaac07-complete-archive'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
job=json.loads((p/'receipts/jobs.json').read_text())['gpu_4090']
status=subprocess.check_output(['sacct','-j',job,'--format=JobID,State,ExitCode,Elapsed','-n','-X'],text=True)
assert 'COMPLETED' in status and '0:0' in status and (p/f'receipts/exit-{job}.txt').read_text().strip()=='0'
run=p/f'runs/full-http-{job}'
complete=json.loads((run/'complete.json').read_text());boundary=json.loads((run/'metadata-boundary-summary.json').read_text())
assert complete['complete'] and complete['pass_'] and not complete['resource_tactic_selected'] and not complete['timing_valid']
assert sum(x['samples']*x['completion_tokens'] for x in complete['requests'])==112
assert boundary['pass_'] and not boundary['resource_enabled'] and boundary['last']['adapter_depth_after_model']==0
assert boundary['last']['actual_prefill_updater_calls_inside_notified_boundary']>0
assert boundary['last']['adapter_counters']['graph_updates']>0
for record in (complete,boundary):
 for n,h in record.get('files',record.get('geometry_files',{})).items():assert sha(run/n)==h,n
suite=ET.parse(p/'receipts/cpu-tests.xml').getroot().find('testsuite');assert tuple(suite.attrib[n] for n in ('tests','failures','errors','skipped'))==('49','0','0','0')
router=json.loads((run/'prefix-router-summary.json').read_text())
assert router['pass_'] and router['last']['counters']['native_calls']>=36 and router['last']['counters']['prepared_attempts']==0
for n,h in router['files'].items():assert sha(run/n)==h,n
previous=b/'sgi-http-metadata-boundary-8739e37-75544a17-20261001/runs/full-http-1648281'
comparisons={};token_count=0
for name in ('short-128','prefill-1536','prefix-hit-1536-plus128','prefill-6500','mixed-batch'):
 current=json.loads((run/(name+'.json')).read_text());original=json.loads((previous/(name+'.json')).read_text())
 assert current['payload']==original['payload'] and current['status']==original['status']==200
 rows=lambda value: value if isinstance(value,list) else [value]
 a=rows(json.loads(current['response']));d=rows(json.loads(original['response']))
 assert len(a)==len(d) and all(x['output_ids']==y['output_ids'] for x,y in zip(a,d))
 count=sum(len(x['output_ids']) for x in a);token_count+=count
 comparisons[name]={'payload_equal':True,'full_token_ids_exact':True,'tokens':count,'current_sha256':sha(run/(name+'.json')),'previous_sha256':sha(previous/(name+'.json'))}
assert token_count==112
(run/'native-full-token-comparison.json').write_text(json.dumps(dict(all_full_token_ids_exact=True,tokens=token_count,previous=str(previous),comparisons=comparisons,resource_enabled=False,historical_token_divergence_resolved=False),indent=2)+'\n')
files={};sources={}
for parent,dirs,names in os.walk(p):
 dirs[:]=[d for d in dirs if d not in ('cache','sdk-libraries','__pycache__','.pytest_cache') and not d.startswith('xdg-')]
 for n in names:
  f=Path(parent)/n;name=str(f.relative_to(p));files[name]=sha(f);sources[name]=f
helper=Path(__file__);files[helper.name]=sha(helper);sources[helper.name]=helper
out.mkdir();a=out/'raw-native-http-prefix-router.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for n in sorted(files):t.add(sources[n],arcname=n,recursive=False)
with tarfile.open(a) as t:
 assert set(t.getnames())==set(files)
 for n,h in files.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h,n
receipt=dict(pass_native_http_prefix_router=True,binding=json.loads((p/'binding.json').read_text()),sacct=status,job=job,cpu_tests_passed=49,http=complete,boundary=boundary,prefix_router=router,native_full_token_ids_exact=True,token_count=token_count,files=files,archive_sha256=sha(a),archive_bytes=a.stat().st_size,resource_tactic_selected=False,full_http_resource_qualified=False,timing_valid=False,qualification_authority=False,fresh_cases_consumed=0,default_promotion=False,serving_promotion=False,historical_token_divergence_resolved=False)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ('pass_native_http_prefix_router','archive_sha256','archive_bytes')}))
