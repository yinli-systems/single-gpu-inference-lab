"""Archive the exact CPU preparation run; no GPU qualification authority."""
import hashlib
import json
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

b = Path('/ssd/scxi253')
p = b / 'sgi-http-preparation-cpu-b6e20e3-20261001'
out = b / 'sgi-http-preparation-cpu-b6e20e3-complete-archive'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
binding = json.loads((p/'binding.json').read_text())
assert binding['harness_commit'] == 'b6e20e3d5220cb226ff961e26af5434c381ae043'
assert (p/'exit.txt').read_text().strip() == '0'
suite = ET.parse(p/'tests.xml').getroot().find('testsuite')
assert int(suite.attrib['tests']) == 173 and int(suite.attrib['skipped']) == 10
assert all(int(suite.attrib.get(key, 0)) == 0 for key in ('failures', 'errors'))
files = {name: p/name for name in binding['files']}
for name, digest in binding['files'].items():
    assert sha(files[name]) == digest
for name in ('binding.json','tests.xml','tests.log','exit.txt'):
    files[name] = p/name
for name in ('http-preparation-cpu-b6e20e3.json','http-preparation-cpu-b6e20e3.tar.gz'):
    files['source-bundle/'+name] = b/name
assert sha(b/'http-preparation-cpu-b6e20e3.tar.gz') == binding['archive_sha256']
files[Path(__file__).name] = Path(__file__)
digests = {name:sha(path) for name,path in files.items()}
out.mkdir()
archive = out/'raw-http-preparation-cpu.tar.gz'
with tarfile.open(archive,'w:gz') as stream:
    for name,path in sorted(files.items()):stream.add(path,arcname=name,recursive=False)
with tarfile.open(archive) as stream:
    assert set(stream.getnames()) == set(digests)
    for member in stream:
        assert member.isfile()
        assert hashlib.sha256(stream.extractfile(member).read()).hexdigest() == digests[member.name]
receipt = dict(harness_commit=binding['harness_commit'],passed=163,skipped=10,failures=0,errors=0,files=digests,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,qualification_authority=False,full_http_resource_qualified=False,fresh_cases_consumed=0,historical_token_divergence_resolved=False)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({key:receipt[key] for key in ('passed','skipped','archive_sha256','archive_bytes')}))
