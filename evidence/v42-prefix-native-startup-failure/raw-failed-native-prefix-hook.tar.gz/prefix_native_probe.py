"""Full-model HTTP geometry observation; resource off, no valid timing claims."""
from pathlib import Path
import argparse, asyncio, hashlib, json, os, random, signal, socket, subprocess, sys, time
import aiohttp

def save(path, data): path.write_text(json.dumps(data, indent=2) + '\n')
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()

async def run(root, out):
    if out.exists(): raise FileExistsError('Preserve earlier evidence')
    out.mkdir(parents=True)
    binding = json.loads((root / 'binding.json').read_text())
    src = Path(binding['sglang_source'])
    overlay = Path(binding['flashinfer_overlay'])
    observer = root / 'research/selector_v4/serving/prefix_router_native_server.py'
    assert sha(observer) == binding['observer_sha256']
    model = Path('/ssd/scxi253/check-before-act-20260927/models/Qwen3-4B-Instruct-2507')
    config = json.loads((model / 'config.json').read_text())
    assert config['num_hidden_layers'] == 36
    with socket.socket() as sock:
        sock.bind(('127.0.0.1', 0)); port = sock.getsockname()[1]
    env = dict(os.environ, PYTHONPATH=str(root) + ':' + str(src / 'python') + ':' + str(overlay),
               SGI_PREFILL_GEOMETRY_DIR=str(out / 'geometry'), SGI_METADATA_BOUNDARY_DIR=str(out / 'boundaries'), SGI_METADATA_BACKEND_SHA256=binding['sglang_backend_sha256'],
               HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    command = [sys.executable, str(observer), '--model-path', str(model),
               '--host', '127.0.0.1', '--port', str(port), '--attention-backend', 'flashinfer',
               '--dtype', 'bfloat16', '--mem-fraction-static', '0.80', '--context-length', '8192',
               '--chunked-prefill-size', '1024', '--max-running-requests', '16',
               '--cuda-graph-max-bs-decode', '16', '--page-size', '16', '--skip-tokenizer-init',
               '--random-seed', '42', '--disable-overlap-schedule']
    save(out / 'environment.json', dict(binding=binding, command=command,
          model_config_sha256=sha(model / 'config.json'),
          model_index_sha256=sha(model / 'model.safetensors.index.json'),
          full_model_layers=36, dtype='bfloat16', probe_sha256=sha(Path(__file__)),
          resource_tactic_selected=False, timing_valid=False))
    log = (out / 'server.log').open('w')
    proc = subprocess.Popen(command, env=env, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
    results = []
    try:
        url = f'http://127.0.0.1:{port}'
        async with aiohttp.ClientSession(timeout=aiohttp.ClientTimeout(total=240)) as session:
            start = time.monotonic()
            while time.monotonic() - start < 900:
                if proc.poll() is not None: raise RuntimeError(f'Server exited {proc.returncode}')
                try:
                    async with session.get(url + '/health', timeout=aiohttp.ClientTimeout(total=3)) as response:
                        if response.status == 200: break
                except (aiohttp.ClientError, asyncio.TimeoutError): pass
                await asyncio.sleep(.5)
            else: raise TimeoutError('Server startup')
            rng = random.Random(2026100137)
            prefix = [rng.randrange(200, 16000) for _ in range(6500)]
            async def request(name, inputs):
                count = len(inputs) if isinstance(inputs[0], list) else 1
                payload = dict(input_ids=inputs, sampling_params=dict(temperature=0, max_new_tokens=16, ignore_eos=True), stream=False)
                async with session.post(url + '/generate', json=payload) as response:
                    text = await response.text()
                    save(out / (name + '.json'), dict(status=response.status, payload=payload, response=text))
                    if response.status != 200: raise RuntimeError(f'{name}: HTTP {response.status}: {text[:2000]}')
                data = json.loads(text); rows = data if isinstance(data, list) else [data]
                assert len(rows) == count and all(r['meta_info']['completion_tokens'] == 16 and r['meta_info']['finish_reason']['type'] == 'length' for r in rows), name
                results.append(dict(name=name, samples=count, completion_tokens=16, complete=True))
            await request('short-128', prefix[:128])
            await request('prefill-1536', prefix[:1536])
            await request('prefix-hit-1536-plus128', prefix[:1536] + [rng.randrange(200,16000) for _ in range(128)])
            await request('prefill-6500', prefix)
            await request('mixed-batch', [prefix[:256], prefix[:3072], prefix[:6400]])
        boundary_paths = sorted((out / 'boundaries').glob('boundaries-*.jsonl'))
        boundary_rows = [json.loads(line) for f in boundary_paths for line in f.read_text().splitlines()]
        assert boundary_rows and all(r['adapter_depth_after_model'] == 0 and r['registered_resource_geometries'] == 0 and not r['resource_tactic_selected'] for r in boundary_rows)
        assert max(r['actual_prefill_updater_calls_inside_notified_boundary'] for r in boundary_rows) > 0
        assert max(r['adapter_counters']['graph_updates'] for r in boundary_rows) > 0
        save(out / 'metadata-boundary-summary.json', dict(pass_=True, records=len(boundary_rows), last=boundary_rows[-1], files={str(f.relative_to(out)):sha(f) for f in boundary_paths}, resource_enabled=False, timing_valid=False))
        router_paths = sorted((out / 'boundaries').glob('prefix-router-*.jsonl'))
        router_rows = [json.loads(line) for f in router_paths for line in f.read_text().splitlines()]
        assert router_rows and all(r['frozen_input_geometries'] == 0 and r['counters']['prepared_attempts'] == 0 for r in router_rows)
        assert max(r['counters']['native_calls'] for r in router_rows) >= 36
        save(out / 'prefix-router-summary.json', dict(pass_=True, records=len(router_rows), last=router_rows[-1], files={str(f.relative_to(out)):sha(f) for f in router_paths}, resource_enabled=False, timing_valid=False))
        paths = sorted((out / 'geometry').glob('*.jsonl'))
        geometry = [json.loads(line) for f in paths for line in f.read_text().splitlines()]
        assert geometry and all(g['diagnostic_only'] and not g['resource_tactic_selected'] and not g['timing_valid'] for g in geometry)
        save(out / 'complete.json', dict(complete=True, pass_=True, requests=results,
             geometry_records=len(geometry), geometry_files={str(f.relative_to(out)):sha(f) for f in paths},
             observed_layouts=sorted({g['layout'] for g in geometry}),
             observed_page_sizes=sorted({g['page_size'] for g in geometry}),
             observed_causal_modes=sorted({g['causal'] for g in geometry}),
             observed_splits=sorted({str(g['actual_split']) for g in geometry}),
             untracked_metadata_records=sum(any(v is None for v in g['metadata_version_tracking'].values()) for g in geometry),
             fresh_kernel_cases_consumed=0, resource_tactic_selected=False, timing_valid=False,
             full_http_resource_qualified=False, historical_token_divergence_resolved=False))
    except BaseException as exc:
        save(out / 'failure.json', dict(type=type(exc).__name__, message=str(exc))); raise
    finally:
        if proc.poll() is None:
            os.killpg(proc.pid, signal.SIGTERM)
            try: proc.wait(timeout=20)
            except subprocess.TimeoutExpired:
                os.killpg(proc.pid, signal.SIGKILL); proc.wait(timeout=10)
        log.close()

if __name__ == '__main__':
    parser = argparse.ArgumentParser(); parser.add_argument('--root', type=Path, required=True); parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args(); asyncio.run(run(args.root, args.out))
