"""Retain the Native-only prefix hook startup failure and exact source."""
from pathlib import Path
import hashlib,json,os,subprocess,tarfile
b=Path('/ssd/scxi253');p=b/'sgi-http-prefix-native-fca11f2-75544a17-20261001';out=b/'sgi-http-prefix-native-fca11f2-failed-archive'
job='1648627';status=subprocess.check_output(['sacct','-j',job,'--format=JobID,State,ExitCode,Elapsed','-n','-X'],text=True)
assert 'FAILED' in status and '1:0' in status
r=p/f'runs/full-http-{job}';failure=json.loads((r/'failure.json').read_text());log=(r/'server.log').read_text()
assert "NameError: name 'RadixAttention' is not defined" in log and not (r/'complete.json').exists()
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest();files={}
for parent,dirs,names in os.walk(p):
 dirs[:]=[d for d in dirs if d not in ('cache','sdk-libraries','__pycache__','.pytest_cache')]
 for n in names:
  f=Path(parent)/n
  if f.is_file():files[str(f.relative_to(p))]=f
files[Path(__file__).name]=Path(__file__);digests={n:sha(f) for n,f in files.items()}
out.mkdir();a=out/'raw-failed-native-prefix-hook.tar.gz'
with tarfile.open(a,'w:gz') as t:
 for n,f in sorted(files.items()):t.add(f,arcname=n,recursive=False)
with tarfile.open(a) as t:
 assert set(t.getnames())==set(digests)
 for n,h in digests.items():assert hashlib.sha256(t.extractfile(n).read()).hexdigest()==h
receipt=dict(complete_archive_of_failed_attempt=True,pass_native_http=False,binding=json.loads((p/'binding.json').read_text()),sacct=status,job=job,failure=failure,root_cause='Function recompilation lost original future-annotations compiler flag; TYPE_CHECKING-only RadixAttention name evaluated during definition.',files=digests,archive_sha256=sha(a),archive_bytes=a.stat().st_size,fresh_cases_consumed=0,qualification_authority=False,full_http_resource_qualified=False,historical_token_divergence_resolved=False)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:receipt[k] for k in ('complete_archive_of_failed_attempt','archive_sha256','archive_bytes')}))
