"""Finite source-bound CPU preparation run, CUDA explicitly invisible."""
import hashlib
import json
import os
import subprocess
import tarfile
from pathlib import Path

b=Path('/ssd/scxi253');stem='http-preparation-cpu-d14c22b'
p=b/('sgi-'+stem+'-20261001')
binding=json.loads((b/(stem+'.json')).read_text())
assert binding['harness_commit']=='d14c22b2f2fd8702e80fba2f0001ec12101f45bf'
archive=b/(stem+'.tar.gz')
assert hashlib.sha256(archive.read_bytes()).hexdigest()==binding['archive_sha256']
p.mkdir()
with tarfile.open(archive) as t:
    assert set(t.getnames())==set(binding['files'])
    for m in t:
        n=Path(m.name);assert m.isfile() and not n.is_absolute() and '..' not in n.parts
        raw=t.extractfile(m).read();assert hashlib.sha256(raw).hexdigest()==binding['files'][m.name]
        f=p/n;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(raw)
(p/'binding.json').write_text(json.dumps(binding,indent=2)+'\n')
s=b/'sgi-official-wheel-validation-75544a17-20261001/wheel-overlay'
e=b/'q7b-engines-20260925T1247Z/envs/sglang312/bin/python'
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',PYTHONPATH=':'.join(map(str,(p,s,s/'test-support'))),PYTEST_DISABLE_PLUGIN_AUTOLOAD='1',SGI_REVIEWED_BACKEND_SOURCE=str(b/'sgi-http-ownership-current-main-3825c5a-post1/candidate/python/sglang/srt/layers/attention/flashinfer_backend.py'))
with (p/'tests.log').open('x') as log:
    r=subprocess.run([str(e),'-m','pytest','-q','research/selector_v4/serving','research/selector_v4/public_qualification','--junitxml='+str(p/'tests.xml')],env=env,cwd=p,stdout=log,stderr=subprocess.STDOUT,timeout=300)
(p/'exit.txt').write_text(str(r.returncode)+'\n')
print((p/'tests.log').read_text()[-1200:])
raise SystemExit(r.returncode)
