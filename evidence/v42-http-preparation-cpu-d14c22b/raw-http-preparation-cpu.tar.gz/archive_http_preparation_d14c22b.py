"""Archive the exact CPU preparation run; no GPU qualification authority."""
import hashlib
import json
import tarfile
import xml.etree.ElementTree as ET
from pathlib import Path

b = Path('/ssd/scxi253')
p = b / 'sgi-http-preparation-cpu-d14c22b-20261001'
out = b / 'sgi-http-preparation-cpu-d14c22b-complete-archive'
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
binding = json.loads((p/'binding.json').read_text())
assert binding['harness_commit'] == 'd14c22b2f2fd8702e80fba2f0001ec12101f45bf'
assert (p/'exit.txt').read_text().strip() == '0'
suite = ET.parse(p/'tests.xml').getroot().find('testsuite')
assert int(suite.attrib['tests']) == 190 and int(suite.attrib['skipped']) == 10
assert all(int(suite.attrib.get(key, 0)) == 0 for key in ('failures', 'errors'))
files = {name: p/name for name in binding['files']}
for name, digest in binding['files'].items():
    assert sha(files[name]) == digest
for name in ('binding.json','tests.xml','tests.log','exit.txt'):
    files[name] = p/name
for name in ('http-preparation-cpu-d14c22b.json','http-preparation-cpu-d14c22b.tar.gz'):
    files['source-bundle/'+name] = b/name
assert sha(b/'http-preparation-cpu-d14c22b.tar.gz') == binding['archive_sha256']
files[Path(__file__).name] = Path(__file__)
files['run_http_preparation_d14c22b.py'] = b/'run_http_preparation_d14c22b.py'
digests = {name:sha(path) for name,path in files.items()}
out.mkdir()
archive = out/'raw-http-preparation-cpu.tar.gz'
with tarfile.open(archive,'w:gz') as stream:
    for name,path in sorted(files.items()):stream.add(path,arcname=name,recursive=False)
with tarfile.open(archive) as stream:
    assert set(stream.getnames()) == set(digests)
    for member in stream:
        assert member.isfile()
        assert hashlib.sha256(stream.extractfile(member).read()).hexdigest() == digests[member.name]
receipt = dict(harness_commit=binding['harness_commit'],passed=180,skipped=10,failures=0,errors=0,files=digests,archive_sha256=sha(archive),archive_bytes=archive.stat().st_size,qualification_authority=False,full_http_resource_qualified=False,fresh_cases_consumed=0,historical_token_divergence_resolved=False)
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({key:receipt[key] for key in ('passed','skipped','archive_sha256','archive_bytes')}))
